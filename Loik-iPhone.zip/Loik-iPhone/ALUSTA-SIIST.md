# Lõik — iPhone’i rakenduse esimene lähtekoodiversioon

See on sinu oma iPhone’i videotöötlusrakenduse projekt, mitte OpusClipi koopia.
Vajab iOS 17 või uuemat. Ei sisalda tellimust, vesimärki ega tasulist AI API-t.

**See pakett ei ole veel telefoni paigaldatav äpp.** Siin on lähtekood, Xcode’i
projekt, testid ja GitHub Actionsi ehitusfail. Selles Windowsi keskkonnas pole
Apple’i kompilaatorit, iOS-i simulaatorit ega sinu iPhone’i ühendust. iOS-i ehitus,
testid ja päris seadme kontroll on veel tegemata. Vigu võib esineda.

## Mis on lähtekoodis teostatud?

- Video import Fotode valijast või Failidest.
- Klipi alguse ja lõpu valimine ning eelvaade.
- 9:16 keskelt kärbitud püstformaat või algne kuvasuhe.
- MP4 loomine koos esimese helirajaga, jagamine ja salvestamine Fotodesse.
- Kuni 55-sekundilise valiku subtiitrid Apple’i kohalikust kõnetuvastusest,
  ainult toetatud keelte ja seadmete puhul. Võrgupõhist varuvarianti ei kasutata.
- Subtiitrite teksti parandamine ja videopildile põletamine.
- Käsitsi sisestatud teksti ühtlane jaotamine klipile. See ei sünkrooni teksti kõnega.
- Kuni kuus 30-sekundilist alguspunkti, mis on ühtlaselt video peale jaotatud.
  Need ei ole AI valitud parimad hetked.

**Puuduvad:** sisu mõistev parimate hetkede valik, automaatne rääkija jälgimine,
YouTube’i lingist import, pika video täielik transkriptsioon, mitme klipi korraga
eksport, püsiv projektide kogu ja automaatne sotsiaalmeediasse postitamine.
Eesti keele automaatseid subtiitreid ei saa lubada. Projekt on telefoni ajutises
mälus; ekspordi vajalik klipp enne rakenduse sulgemist. Väga pikk video vajab
vaba salvestusruumi ja võib olla telefoni jaoks liiga koormav.

## Windows + iPhone: tasuta ehitamise tee

Oma Mac pole tingimata vajalik: GitHub saab lähtekoodi macOS-i virtuaalmasinas
kompileerida. Seejärel saab allkirjastamata IPA Windowsi AltServeri ja iPhone’i
AltStore Classicu abil oma Apple’i kontoga allkirjastada ja paigaldada.

Tasuta standardrunner on GitHubi **avalikus** hoidlas tasuta. Avalik tähendab,
et teised näevad sinu lähtekoodi. Ära lisa sinna oma videoid, paroole ega muid
isiklikke faile. See juhend ei avalda midagi sinu eest. Kui sa ei soovi avalikku
lähtekoodi, on alternatiiv laenatud Mac ja kohalik Xcode; ära muuda töövoo
tasuta-kontrolli lihtsalt möödapääsuks.

### 1. Loo ehitusfail GitHubis

1. Paki ZIP Windowsis lahti. Leia kaust, milles on `Loik.xcodeproj`, `Loik`,
   `LoikTests` ja `.github`.
2. Logi oma tasuta GitHubi kontole ja loo uus **Public** hoidla, näiteks `loik-iphone`.
3. Laadi selle kausta **sisu** hoidla juurkausta. `.github/workflows/iphone.yml`
   peab kindlasti kaasas olema. Videofaile sinna ära laadi.
4. Ava hoidlas **Actions → Build iPhone app → Run workflow**.
5. Oota, kuni testid ja ehitamine lõpevad. Kui töövoog on punane, on vaja selle
   konkreetne ehitusviga parandada; IPA-d siis veel ei ole.
6. Rohelise töövoo lehel laadi **Artifacts → Loik-unsigned-IPA** alla. Paki
   allalaaditud artefakti ZIP lahti: sees on `Loik-unsigned.ipa`.

Töövoog käivitub ainult käsitsi. macOS-i ehitus on blokeeritud privaatses hoidlas.
Kasutatakse standardset `macos-15` runnerit, mitte tasulist suuremat runnerit.
Artefakti hoitakse 7 päeva; laadi see alla ja kustuta artefakt pärast kasutamist.
Arvesta oma konto artefaktimahu piiridega ja hoia tasulise kasutuse eelarve nullis.
Ära lisa maksekaarti ega lülita tasulist kasutust selle juhendi pärast sisse.

### 2. Paigalda Windowsi abil

Järgi AltStore Classicu ametlikku Windowsi juhendit:
https://faq.altstore.io/altstore-classic/how-to-install-altstore-windows

1. Paigalda ametlik AltServer ning juhendis nõutud Apple’i iTunes ja iCloud.
   Järgi seal ka Microsoft Store’i versioonide kohta antud juhiseid.
2. Ühenda iPhone USB-kaabliga, ava lukustus ja usalda oma arvutit.
3. Vali AltServeris **Install AltStore → sinu iPhone**. Oma Apple’i kontoga
   sisselogimine toimub AltServeris; ära saada konto parooli kellelegi vestluses.
4. Luba iPhone’is vajadusel **Settings → Privacy & Security → Developer Mode**
   ning usalda oma arendajaprofiili AltStore’i juhendi järgi.
5. Tõsta `Loik-unsigned.ipa` iPhone’i Failidesse, näiteks enda iCloud Drive’i kaudu.
6. Hoia AltServer Windowsis töös. Ava iPhone’is **AltStore Classic → My Apps → +**
   ja vali IPA. Kasuta **Classicut**, mitte AltStore PAL-i.
7. Kui allkirjastamine ja paigaldus õnnestuvad, ava iPhone’i avakuvalt **Lõik**.

Tasuta Apple’i konto korral aeguvad allkirjad 7 päevaga. Uuenda neid enne
aegumist AltStore’i **Refresh All** nupuga, kui AltServer on kättesaadav.
Apple piirab tasuta kõrvalpaigaldatud rakenduste arvu; AltStore ise kasutab samuti
ühte kohta. OS-i või teenuste muudatused võivad paigaldust mõjutada.

IPA ehitamine ei allkirjasta rakendust ega laadi seda App Store’i. GitHubi töövoog
ei vaja Apple’i parooli, sertifikaati ega makseandmeid.

## Kui saad hiljem Maci kasutada

1. Paigalda Xcode ja ava `Loik.xcodeproj`.
2. Vali **Loik** target → **Signing & Capabilities** → oma **Personal Team**.
3. Kui bundle ID on hõivatud, muuda `local.loik.editor` enda unikaalseks ID-ks.
4. Ühenda iPhone, vali see käivitusseadmeks ja vajuta **Run**.
5. Testide jaoks vali iPhone’i simulaator ja **Product → Test**.

## Kasutamine ja esimene kontroll telefonis

1. Impordi esialgu lühike, näiteks 20-sekundiline video.
2. Vali algus ja lõpp. Kontrolli, et eelvaade peatub lõpus.
3. Proovi 9:16 vormingut: keskelt kärpimine võib servas oleva rääkija välja jätta.
4. Lisa tekst käsitsi või proovi toetatud keeles kõnetuvastust. Kontrolli kirjavigu.
5. Vajuta **Loo MP4**, hoides rakendust avatuna. Seejärel **Salvesta Fotodesse**.
6. Vaata Fotodes tulemust: õige suund, pikkus, heli, kärbe ja subtiitrite ajastus.
7. Korda ka püstise ja pööratud lähtevideoga, helita videoga, keeldutud kõne-
   ja Fotode lubadega. Proovi seejärel pikemat videot.

Subtiitrite eelvaade on ligikaudne. Lõpliku MP4 kujundust tuleb kontrollida
Fotodes. Pärast teksti või vormingu muutmist vajuta uuesti **Loo MP4**.
Kui kohalik keeletugi puudub, kasuta käsitsi teksti; see ei ole tasuline funktsioon.

## Privaatsus ja tehniline teave

Rakendus ise ei laadi videot meie serverisse ega kasuta analüütikat või kontot.
Fotode valija võib iCloudis oleva video Apple’ilt alla laadida. Apple’i kõnetuvastus
käivitatakse ainult `requiresOnDeviceRecognition = true` ja kontrollitud kohaliku
toe korral. Mikrofonile ligipääsu pole vaja: töödeldakse juba salvestatud heli.
Jagamisel valid ise sihtkoha.

SwiftUI, AVFoundation, PhotosUI, Photos ja Speech. iOS 17+, Swift 5 režiim.
Väliseid rakenduse teeke pole. Testifail katab klipivalikute piire ja käsitsi
subtiitrite ajastust; see ei asenda seadmes videotöötluse kontrollimist.

Ametlikud allikad (kontrollitud 31.10.2026):

- Apple’i tasuta konto ja 7 päeva piir:
  https://developer.apple.com/help/account/basics/about-your-developer-account
- AltStore Classicu Windowsi paigaldus:
  https://faq.altstore.io/altstore-classic/how-to-install-altstore-windows
- AltStore’i uuendamine ja rakenduste piirid:
  https://faq.altstore.io/altstore-classic/your-altstore
- GitHubi standardrunnerite tasuta kasutus ja salvestusmaht:
  https://docs.github.com/en/billing/concepts/product-billing/github-actions
- Apple’i kohaliku kõnetuvastuse tugi:
  https://developer.apple.com/documentation/speech/sfspeechrecognizer/supportsondevicerecognition
