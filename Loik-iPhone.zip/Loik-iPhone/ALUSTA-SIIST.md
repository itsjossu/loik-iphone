# Loik 0.2 for iPhone

Native, free local video clipping for iOS 17+.

## Use
1. Tap +, then Photo Library or Files to import a video.
2. Choose clip length, count, language, aspect ratio, headline and caption style.
3. Tap Get clips in 1 click. Keep the app open while processing.
4. Preview rated clips in the two-column gallery. Open any clip to see its rating reasons, play it, save it or share it.
5. Use the project menu to save/share all clips or generate another batch.

Projects, sources, thumbnails and clips are stored locally and survive app restarts. They use device storage and are excluded from iCloud backup. Uninstalling the app deletes them: export important videos first.

## How highlights and scores work
The entire source is streamed for half-second audio RMS measurements. With supported on-device speech recognition, sequential 50-second windows are transcribed. Candidate clips are compared using opening words, speech pace, lexical variety, speech coverage, utterance endings, audio energy and variation. The highest-scoring moments are selected with no more than 15% pairwise overlap.

Scores are computed editorial heuristics out of 100, not a trained virality model or predicted view count. Audio-only ranking is clearly labeled when speech is unavailable. Silent or unsupported speech sections may lack captions. English works only when the device has local support for that locale; no cloud fallback is used.

Each chosen moment is rendered to a real MP4 with a thumbnail, optional headline and timed burned-in captions. Batches are sequential to keep memory use low; completed clips are saved as they finish. Very short sources yield fewer distinct clips. The Stop button preserves completed clips. Interruptions or forced termination can leave the current unfinished clip unrendered.

## Limits
Center cropping does not track speakers. No YouTube-link downloader, server AI, automatic social publishing or promise of viral results. Full-video speech analysis can take significant time, battery and storage. Sources up to six hours are accepted, but short videos are recommended first. All visible app text is English.

## Build and install
The existing GitHub workflow in itsjossu/loik-iphone extracts this archive, runs simulator tests, builds Release for iPhoneOS and packages an unsigned IPA. It uses public-repository standard runners only and runs manually. No Apple credentials are stored in GitHub.

On a Mac: open Loik.xcodeproj in Xcode, choose your Personal Team and run on your iPhone. For Windows sideloading, sign the unsigned IPA with your own Apple account using your preferred legitimate sideloading tool. AltStore Classic's official guide: https://faq.altstore.io/altstore-classic/how-to-install-altstore-windows

Free Apple-account signatures usually require refreshing every seven days. The IPA needs iOS 17 or later. Keep the same bundle ID to update the previous build and retain the new project library.

## Verification
See KONTROLL.md for the current verification boundary. Source syntax checks are not an Apple SDK build. CI tests include content-sensitive ranking, overlap limits, caption rebasing, metadata round trips and real AVFoundation trim/caption/aspect exports.

The --preview-gallery and --preview-settings launch arguments are exclusively for clearly labeled CI layout previews. They create in-memory sample cards and never run during normal use. Their sample ratings are not analysis results.
