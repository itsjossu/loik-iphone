# Xclip 0.5 for iPhone

Native, free local video clipping for iOS 17+.

## Use
1. Tap +, then paste a YouTube video/Shorts link and tap Import from YouTube, or choose Photo Library or Files. YouTube import uses local extraction on the iPhone, with no remote fallback server. Restricted videos and some public links may be unavailable. Use videos you own or have permission to process.
2. Choose clip length, count, language, aspect ratio, headline and caption style.
3. Tap Get clips in 1 click. Keep the app open while processing.
4. Preview rated clips in the two-column gallery. Open any clip to see its rating reasons, play it, save it or share it.
5. Use the project menu to save/share all clips or generate another batch.

Projects, sources, thumbnails and clips are stored locally and survive app restarts. They use device storage and are excluded from iCloud backup. Uninstalling the app deletes them: export important videos first.

## How highlights and scores work
The entire source is streamed for half-second audio RMS measurements. With supported on-device speech recognition, sequential 50-second windows are transcribed. Candidate clips are compared using opening words, speech pace, lexical variety, speech coverage, utterance endings, audio energy and variation. The highest-scoring moments are selected with no more than 15% pairwise overlap.

Scores are computed editorial heuristics out of 100, not a trained virality model or predicted view count. Audio-only ranking is clearly labeled when speech is unavailable. Silent or unsupported speech sections may lack captions. English works only when the device has local support for that locale; no cloud fallback is used.

Each chosen moment is rendered to a real MP4 with a thumbnail, optional headline and timed burned-in captions. Batches are sequential to keep memory use low; completed clips are saved as they finish. Very short sources yield fewer distinct clips. The Stop button preserves completed clips. Interruptions or forced termination can leave the current unfinished clip unrendered.

## Limits
The full source frame is fitted within the chosen aspect ratio over a softened background. Text shrinks to stay inside its safe box and is omitted if it still cannot fit. Speaker tracking, server AI, automatic social publishing and promises of viral results are not included. Full-video speech analysis can take significant time, battery and storage. Sources up to six hours are accepted, but short videos are recommended first. All visible app text is English.

## Build and install
The existing GitHub workflow in itsjossu/loik-iphone extracts this archive, runs simulator tests, builds Release for iPhoneOS and packages an unsigned IPA. It uses public-repository standard runners only and runs manually. No Apple credentials are stored in GitHub.

On a Mac: open Loik.xcodeproj in Xcode, choose your Personal Team and run on your iPhone. For Windows sideloading, sign the unsigned IPA with your own Apple account using your preferred legitimate sideloading tool. AltStore Classic's official guide: https://faq.altstore.io/altstore-classic/how-to-install-altstore-windows

Free Apple-account signatures usually require refreshing every seven days. The IPA needs iOS 17 or later. Keep the same bundle ID to update the previous build and retain the new project library.

## Verification
See KONTROLL.md for the current verification boundary. Source syntax checks are not an Apple SDK build. CI tests include YouTube-link validation, content-sensitive ranking, overlap limits, caption rebasing, metadata round trips and real AVFoundation trim/caption/aspect exports.

The --preview-gallery and --preview-settings launch arguments are exclusively for clearly labeled CI layout previews. They create in-memory sample cards and never run during normal use. Their sample ratings are not analysis results.
