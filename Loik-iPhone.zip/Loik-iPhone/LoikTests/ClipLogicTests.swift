import XCTest
import AVFoundation
import UIKit
@testable import Loik

final class ClipLogicTests: XCTestCase {
    func testShortSourceIsNotExtendedBeyondItsEnd() {
        let clips = ClipLogic.suggestions(duration: 2.5)
        XCTAssertEqual(clips.count, 1)
        XCTAssertEqual(clips[0].start, 0)
        XCTAssertEqual(clips[0].end, 2.5)
    }

    func testLongSourceSuggestionsReachBothEndsAndStayInBounds() {
        let clips = ClipLogic.suggestions(duration: 3600)
        XCTAssertEqual(clips.count, 6)
        XCTAssertEqual(clips.first?.start, 0)
        XCTAssertEqual(clips.last?.end, 3600)
        for clip in clips {
            XCTAssertGreaterThanOrEqual(clip.start, 0)
            XCTAssertLessThanOrEqual(clip.end, 3600)
            XCTAssertEqual(clip.end - clip.start, 30, accuracy: 0.001)
        }
    }

    func testInvalidDurationsDoNotProduceClipRanges() {
        for duration in [0.0, -10.0, Double.nan, Double.infinity] {
            XCTAssertTrue(ClipLogic.suggestions(duration: duration).isEmpty)
        }
    }

    func testManualCaptionsPreserveWordsAndCoverSelectedDuration() {
        let text = "üks kaks kolm neli viis kuus seitse kaheksa üheksa kümme"
        let captions = ClipLogic.manualCaptions(text: text, duration: 17)
        XCTAssertEqual(captions.map(\.text).joined(separator: " "), text)
        XCTAssertEqual(captions.first?.start, 0)
        let last = captions.last!
        XCTAssertEqual(last.start + last.duration, 17, accuracy: 0.001)
        for pair in zip(captions, captions.dropFirst()) {
            XCTAssertEqual(pair.0.start + pair.0.duration, pair.1.start, accuracy: 0.001)
        }
    }

    func testEmptyCaptionsStayEmpty() {
        XCTAssertTrue(ClipLogic.manualCaptions(text: " \n ", duration: 10).isEmpty)
        XCTAssertTrue(ClipLogic.manualCaptions(text: "tere", duration: 0).isEmpty)
    }
}

final class HighlightTests: XCTestCase {
    func testLoudMomentBeatsQuietBeginningAndPicksDistinctClips() {
        var energy = Array(repeating: 0.005, count: 240)
        for index in 120..<160 { energy[index] = 0.4 }
        let clips = HighlightScorer.rank(duration: 120, length: 20, count: 4, energy: energy, captions: [])
        XCTAssertEqual(clips.count, 4)
        XCTAssertGreaterThanOrEqual(clips[0].start, 45)
        XCTAssertLessThanOrEqual(clips[0].start, 70)
        XCTAssertGreaterThan(clips[0].score, clips.last!.score)
        for (index, clip) in clips.enumerated() {
            XCTAssertGreaterThanOrEqual(clip.start, 0)
            XCTAssertLessThanOrEqual(clip.end, 120)
            XCTAssertTrue((1...99).contains(clip.score))
            for other in clips.dropFirst(index + 1) {
                let overlap = max(0, min(clip.end, other.end) - max(clip.start, other.start))
                XCTAssertLessThanOrEqual(overlap, 3.01)
            }
        }
    }

    func testSpeechHookChangesRankingWithIdenticalAudio() {
        let captions = [
            Caption(start: 0, duration: 20, text: "we are going to talk about the ordinary things we usually discuss today"),
            Caption(start: 30, duration: 20, text: "Why this mistake happened and how you can avoid it because the secret is simple")
        ]
        let clips = HighlightScorer.rank(duration: 60, length: 20, count: 1,
                                         energy: Array(repeating: 0.1, count: 120), captions: captions)
        XCTAssertEqual(clips.count, 1)
        XCTAssertGreaterThanOrEqual(clips[0].start, 25)
        XCTAssertTrue(clips[0].usesSpeech)
        XCTAssertTrue(clips[0].reasons.contains("Strong opening language"))
    }

    func testShortSourceProducesOneClipRatherThanDuplicateClips() {
        let clips = HighlightScorer.rank(duration: 8, length: 30, count: 8,
                                         energy: Array(repeating: 0.1, count: 16), captions: [])
        XCTAssertEqual(clips.count, 1)
        XCTAssertEqual(clips[0].start, 0)
        XCTAssertEqual(clips[0].end, 8)
    }

    func testSubtitleRebasingClampsBothClipEdges() {
        let cues = [Caption(start: 5, duration: 8, text: "start"), Caption(start: 18, duration: 6, text: "end")]
        let relative = HighlightScorer.relativeCaptions(cues, start: 10, end: 20)
        XCTAssertEqual(relative.count, 2)
        XCTAssertEqual(relative[0].start, 0)
        XCTAssertEqual(relative[0].duration, 3)
        XCTAssertEqual(relative[1].start, 8)
        XCTAssertEqual(relative[1].duration, 2)
    }

    func testProjectMetadataRoundTripPreservesClipRatings() throws {
        let clip = GeneratedClip(title: "A real moment", start: 10, end: 30, score: 83, reasons: ["Clear speaking pace"],
                                 analysis: "Speech + audio", file: "clip.mp4", thumbnail: "clip.jpg",
                                 captions: [Caption(start: 0, duration: 2, text: "Hello")], aspect: .square)
        let original = VideoProject(title: "My project", duration: 100, sourceFile: "source.mov", clips: [clip])
        let decoded = try JSONDecoder().decode(VideoProject.self, from: JSONEncoder().encode(original))
        XCTAssertEqual(decoded.id, original.id)
        XCTAssertEqual(decoded.clips[0].id, clip.id)
        XCTAssertEqual(decoded.clips[0].score, 83)
        XCTAssertEqual(decoded.clips[0].captions[0].text, "Hello")
        XCTAssertEqual(decoded.clips[0].aspect, .square)
    }
}

final class VideoPipelineTests: XCTestCase {
    func testRealVideoExportTrimsBurnsCaptionsAndChangesAspect() async throws {
        let source = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString + ".mov")
        defer { try? FileManager.default.removeItem(at: source) }
        let writer = try AVAssetWriter(outputURL: source, fileType: .mov)
        let input = AVAssetWriterInput(mediaType: .video, outputSettings: [AVVideoCodecKey: AVVideoCodecType.h264,
            AVVideoWidthKey: 320, AVVideoHeightKey: 180])
        let adaptor = AVAssetWriterInputPixelBufferAdaptor(assetWriterInput: input,
            sourcePixelBufferAttributes: [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA,
                                         kCVPixelBufferWidthKey as String: 320, kCVPixelBufferHeightKey as String: 180])
        writer.add(input)
        XCTAssertTrue(writer.startWriting()); writer.startSession(atSourceTime: .zero)
        var buffer: CVPixelBuffer?
        XCTAssertEqual(CVPixelBufferCreate(kCFAllocatorDefault, 320, 180, kCVPixelFormatType_32BGRA, nil, &buffer), kCVReturnSuccess)
        let pixelBuffer = try XCTUnwrap(buffer)
        CVPixelBufferLockBaseAddress(pixelBuffer, [])
        let address = try XCTUnwrap(CVPixelBufferGetBaseAddress(pixelBuffer))
        memset(address, 90, CVPixelBufferGetDataSize(pixelBuffer))
        CVPixelBufferUnlockBaseAddress(pixelBuffer, [])
        for frame in 0..<30 {
            var attempts = 0
            while !input.isReadyForMoreMediaData {
                try await Task.sleep(nanoseconds: 10_000_000); attempts += 1
                guard attempts < 500 else { throw LoikError.message("Test video writer timed out.") }
            }
            XCTAssertTrue(adaptor.append(pixelBuffer, withPresentationTime: CMTime(value: Int64(frame), timescale: 15)))
        }
        input.markAsFinished()
        await writer.finishWriting()
        XCTAssertEqual(writer.status, .completed)
        for aspect in [Aspect.portrait, .square] {
            let output = try await VideoEngine.export(url: source, start: 0.2, end: 1.6, vertical: true,
                captions: [Caption(start: 0, duration: 1.4, text: "A test caption")], aspect: aspect.ratio,
                headline: "A test headline", style: .mint)
            defer { try? FileManager.default.removeItem(at: output) }
            let asset = AVURLAsset(url: output)
            let duration = try await asset.load(.duration).seconds
            XCTAssertEqual(duration, 1.4, accuracy: 0.1)
            let tracks = try await asset.loadTracks(withMediaType: .video)
            let track = try XCTUnwrap(tracks.first)
            let size = try await track.load(.naturalSize)
            XCTAssertEqual(size.width / size.height, aspect.ratio, accuracy: 0.01)
            let image = try await AVAssetImageGenerator(asset: asset).image(at: CMTime(seconds: 0.5, preferredTimescale: 600)).image
            XCTAssertGreaterThan(image.width, 0)
            var rgba = [UInt8](repeating: 0, count: image.width * image.height * 4)
            let whitePixels = rgba.withUnsafeMutableBytes { bytes -> Int in
                let context = CGContext(data: bytes.baseAddress, width: image.width, height: image.height,
                    bitsPerComponent: 8, bytesPerRow: image.width * 4, space: CGColorSpaceCreateDeviceRGB(),
                    bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue)!
                context.draw(image, in: CGRect(x: 0, y: 0, width: image.width, height: image.height))
                let pixels = bytes.bindMemory(to: UInt8.self)
                return stride(from: 0, to: pixels.count, by: 4).filter {
                    pixels[$0] > 200 && pixels[$0 + 1] > 200 && pixels[$0 + 2] > 200
                }.count
            }
            XCTAssertGreaterThan(whitePixels, 100, "The exported frame should contain the burned-in white headline.")
            let folder = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString + ".jpg")
            try await ProjectStore.thumbnail(video: output, at: 0.5, destination: folder)
            XCTAssertTrue(FileManager.default.fileExists(atPath: folder.path))
            try FileManager.default.removeItem(at: folder)
        }
    }
}
