import XCTest
import AVFoundation
import UIKit
@testable import Loik

final class ClipLogicTests: XCTestCase {
    func testYouTubeLinksAcceptSupportedFormsAndRejectOtherHosts() {
        for link in ["https://youtu.be/abcdefghijk?t=20", "https://www.youtube.com/watch?v=abcdefghijk", "https://youtube.com/shorts/abcdefghijk"] {
            XCTAssertEqual(YouTubeImport.videoID(link), "abcdefghijk")
        }
        for link in ["https://youtube.com.evil.example/watch?v=abcdefghijk", "file:///watch?v=abcdefghijk", "https://youtube.com/watch?v=bad", "https://example.com/abcdefghijk"] {
            XCTAssertNil(YouTubeImport.videoID(link))
        }
    }
    func testShortSourceIsNotExtendedBeyondItsEnd() {
        let clips = ClipLogic.suggestions(duration: 2.5)
        XCTAssertEqual(clips.count, 1)
        XCTAssertEqual(clips[0].start, 0)
        XCTAssertEqual(clips[0].end, 2.5)
    }

    func testLongSourceSuggestionsReachBothEndsAndStayInBounds() {
        let clips = ClipLogic.suggestions(duration: 3600)
        XCTAssertEqual(clips.count, 6)
        XCTAssertEqual(clips.first?.start, 0)
        XCTAssertEqual(clips.last?.end, 3600)
        for clip in clips {
            XCTAssertGreaterThanOrEqual(clip.start, 0)
            XCTAssertLessThanOrEqual(clip.end, 3600)
            XCTAssertEqual(clip.end - clip.start, 30, accuracy: 0.001)
        }
    }

    func testInvalidDurationsDoNotProduceClipRanges() {
        for duration in [0.0, -10.0, Double.nan, Double.infinity] {
            XCTAssertTrue(ClipLogic.suggestions(duration: duration).isEmpty)
        }
    }

    func testManualCaptionsPreserveWordsAndCoverSelectedDuration() {
        let text = "üks kaks kolm neli viis kuus seitse kaheksa üheksa kümme"
        let captions = ClipLogic.manualCaptions(text: text, duration: 17)
        XCTAssertEqual(captions.map(\.text).joined(separator: " "), text)
        XCTAssertEqual(captions.first?.start, 0)
        let last = captions.last!
        XCTAssertEqual(last.start + last.duration, 17, accuracy: 0.001)
        for pair in zip(captions, captions.dropFirst()) {
            XCTAssertEqual(pair.0.start + pair.0.duration, pair.1.start, accuracy: 0.001)
        }
    }

    func testEmptyCaptionsStayEmpty() {
        XCTAssertTrue(ClipLogic.manualCaptions(text: " \n ", duration: 10).isEmpty)
        XCTAssertTrue(ClipLogic.manualCaptions(text: "tere", duration: 0).isEmpty)
    }
}

final class HighlightTests: XCTestCase {
    func testNaturalCutWaitsForSentenceWithinFourSeconds() {
        XCTAssertEqual(HighlightScorer.naturalEnd(start: 0, length: 15, duration: 60,
            boundaries: [11, 18, 20], energy: []), 18)
        XCTAssertEqual(HighlightScorer.naturalEnd(start: 0, length: 15, duration: 60,
            boundaries: [11, 20], energy: []), 15)
    }

    func testPartsShareBoundariesAndEndAtSourceEnd() {
        let cues = [Caption(start: 29, duration: 3, text: "End of sentence.")]
        let parts = HighlightScorer.parts(duration: 64, length: 30, count: 4, energy: [], captions: cues)
        XCTAssertEqual(parts.map(\.title), ["Part 1", "Part 2"])
        XCTAssertEqual(parts.map(\.start), [0, 32])
        XCTAssertEqual(parts.map(\.end), [32, 64])
    }
    func testLoudMomentBeatsQuietBeginningAndPicksDistinctClips() {
        var energy = Array(repeating: 0.005, count: 240)
        for index in 120..<160 { energy[index] = 0.4 }
        let clips = HighlightScorer.rank(duration: 120, length: 20, count: 4, energy: energy, captions: [])
        XCTAssertEqual(clips.count, 4)
        XCTAssertGreaterThanOrEqual(clips[0].start, 45)
        XCTAssertLessThanOrEqual(clips[0].start, 70)
        XCTAssertGreaterThan(clips[0].score, clips.last!.score)
        for (index, clip) in clips.enumerated() {
            XCTAssertGreaterThanOrEqual(clip.start, 0)
            XCTAssertLessThanOrEqual(clip.end, 120)
            XCTAssertTrue((1...99).contains(clip.score))
            for other in clips.dropFirst(index + 1) {
                let overlap = max(0, min(clip.end, other.end) - max(clip.start, other.start))
                XCTAssertLessThanOrEqual(overlap, 3.01)
            }
        }
    }

    func testSpeechHookChangesRankingWithIdenticalAudio() {
        let captions = [
            Caption(start: 0, duration: 20, text: "we are going to talk about the ordinary things we usually discuss today"),
            Caption(start: 30, duration: 20, text: "Why this mistake happened and how you can avoid it because the secret is simple")
        ]
        let clips = HighlightScorer.rank(duration: 60, length: 20, count: 1,
                                         energy: Array(repeating: 0.1, count: 120), captions: captions)
        XCTAssertEqual(clips.count, 1)
        XCTAssertGreaterThanOrEqual(clips[0].start, 25)
        XCTAssertTrue(clips[0].usesSpeech)
        XCTAssertTrue(clips[0].reasons.contains("Strong opening language"))
    }

    func testShortSourceProducesOneClipRatherThanDuplicateClips() {
        let clips = HighlightScorer.rank(duration: 8, length: 30, count: 8,
                                         energy: Array(repeating: 0.1, count: 16), captions: [])
        XCTAssertEqual(clips.count, 1)
        XCTAssertEqual(clips[0].start, 0)
        XCTAssertEqual(clips[0].end, 8)
    }

    func testSubtitleRebasingClampsBothClipEdges() {
        let cues = [Caption(start: 5, duration: 8, text: "start"), Caption(start: 18, duration: 6, text: "end")]
        let relative = HighlightScorer.relativeCaptions(cues, start: 10, end: 20)
        XCTAssertEqual(relative.count, 2)
        XCTAssertEqual(relative[0].start, 0)
        XCTAssertEqual(relative[0].duration, 3)
        XCTAssertEqual(relative[1].start, 8)
        XCTAssertEqual(relative[1].duration, 2)
    }

    func testProjectMetadataRoundTripPreservesClipRatings() throws {
        let clip = GeneratedClip(title: "A real moment", start: 10, end: 30, score: 83, reasons: ["Clear speaking pace"],
                                 analysis: "Speech + audio", file: "clip.mp4", thumbnail: "clip.jpg",
                                 captions: [Caption(start: 0, duration: 2, text: "Hello")], aspect: .square)
        let original = VideoProject(title: "My project", duration: 100, sourceFile: "source.mov", clips: [clip])
        let decoded = try JSONDecoder().decode(VideoProject.self, from: JSONEncoder().encode(original))
        XCTAssertEqual(decoded.id, original.id)
        XCTAssertEqual(decoded.clips[0].id, clip.id)
        XCTAssertEqual(decoded.clips[0].score, 83)
        XCTAssertEqual(decoded.clips[0].captions[0].text, "Hello")
        XCTAssertEqual(decoded.clips[0].aspect, .square)
    }
}

final class DiscoveryAndRankingTests: XCTestCase {
    func testFeedParsesActualViewCountsAndRejectsBadIDs() throws {
        let xml = """
        <feed xmlns:yt="http://www.youtube.com/xml/schemas/2015" xmlns:media="http://search.yahoo.com/mrss/">
        <entry><yt:videoId>abcdefghijk</yt:videoId><title>Why water moves</title><published>2026-10-30T14:00:38+00:00</published><media:group><media:community><media:statistics views="123456"/></media:community></media:group></entry>
        <entry><yt:videoId>bad</yt:videoId><title>Invalid</title><published>2026-10-30T14:00:38+00:00</published></entry>
        </feed>
        """
        let parsed = try VideoFeedParser.parse(Data(xml.utf8), creator: DiscoverCreator.all[0], fetched: Date())
        XCTAssertEqual(parsed.count, 1)
        XCTAssertEqual(parsed[0].views, 123456)
        XCTAssertEqual(parsed[0].title, "Why water moves")
    }
    func testMomentumUsesChannelBaselineAndMissingViewsStayUnknown() {
        let now = Date(timeIntervalSince1970: 1800000000)
        let creator = DiscoverCreator.all[0]
        let videos = (0..<5).map { index in
            DiscoveryVideo(id: "video\(index)", title: "A demonstration", creatorID: creator.id, creator: creator.name,
                published: now.addingTimeInterval(-86400), views: index == 0 ? 24000 : 2400, fetched: now)
        }
        XCTAssertEqual(DiscoverySignals.relativePace(videos[0], among: videos)!, 10, accuracy: 0.01)
        XCTAssertGreaterThan(DiscoverySignals.score(videos[0], among: videos), DiscoverySignals.score(videos[1], among: videos))
        let missing = DiscoveryVideo(id: "unknown", title: "Unknown", creatorID: creator.id, creator: creator.name, published: now, views: nil, fetched: now)
        XCTAssertNil(DiscoverySignals.hourlyViews(missing))
        XCTAssertNil(DiscoverySignals.relativePace(missing, among: videos))
    }
    func testChunkEndsDoNotPretendToBeSentenceEnds() {
        let captions = [Caption(start: 0, duration: 2, text: "This thought keeps going"),
                        Caption(start: 2.1, duration: 2, text: "and ends here."),
                        Caption(start: 4.2, duration: 2, text: "Next thought")]
        let ends = HighlightScorer.completeBoundaries(captions)
        XCTAssertFalse(ends.contains(2))
        XCTAssertTrue(ends.contains(4.1))
    }
    func testRepeatedSpeechIsNotReturnedAsMultipleStories() {
        let text = "Why this surprising experiment works because the solution changes everything we know about water."
        let captions = [Caption(start: 0, duration: 20, text: text), Caption(start: 30, duration: 20, text: text)]
        let picked = HighlightScorer.rank(duration: 60, length: 20, count: 4,
            energy: Array(repeating: 0.1, count: 120), captions: captions)
        XCTAssertEqual(picked.filter(\.usesSpeech).count, 1)
    }
}

final class VideoPipelineTests: XCTestCase {
    func testRealVideoExportTrimsBurnsCaptionsAndChangesAspect() async throws {
        let source = try XCTUnwrap(Bundle(for: Self.self).url(forResource: "test", withExtension: "mp4"))
        let energy = try await AudioAnalyzer.energy(url: source, duration: 3)
        print("PIPELINE: audio analyzed")
        XCTAssertGreaterThanOrEqual(energy.count, 5)
        XCTAssertGreaterThan(energy.max() ?? 0, 0.01)
        let stored = try await ProjectStore.create(from: source, title: "Pipeline test")
        print("PIPELINE: project persisted")
        defer { try? FileManager.default.removeItem(at: ProjectStore.directory(stored.id)) }
        XCTAssertTrue(try ProjectStore.load().contains { $0.id == stored.id })
        XCTAssertTrue(FileManager.default.fileExists(atPath: ProjectStore.url(stored, stored.sourceFile).path))
        for aspect in [Aspect.portrait, .square] {
            print("PIPELINE: exporting \(aspect)")
            let output = try await VideoEngine.export(url: source, start: 0.2, end: 1.6, vertical: true,
                captions: [Caption(start: 0, duration: 1.4, text: "A test caption")], aspect: aspect.ratio,
                headline: "A test headline", style: .mint)
            print("PIPELINE: export complete \(aspect)")
            defer { try? FileManager.default.removeItem(at: output) }
            let asset = AVURLAsset(url: output)
            let duration = try await asset.load(.duration).seconds
            XCTAssertEqual(duration, 1.4, accuracy: 0.1)
            let tracks = try await asset.loadTracks(withMediaType: .video)
            let track = try XCTUnwrap(tracks.first)
            let size = try await track.load(.naturalSize)
            XCTAssertEqual(size.width / size.height, aspect.ratio, accuracy: 0.01)
            let image = try await AVAssetImageGenerator(asset: asset).image(at: CMTime(seconds: 0.5, preferredTimescale: 600)).image
            XCTAssertGreaterThan(image.width, 0)
            var rgba = [UInt8](repeating: 0, count: image.width * image.height * 4)
            let textPixels = rgba.withUnsafeMutableBytes { bytes -> (Int, Int) in
                let context = CGContext(data: bytes.baseAddress, width: image.width, height: image.height,
                    bitsPerComponent: 8, bytesPerRow: image.width * 4, space: CGColorSpaceCreateDeviceRGB(),
                    bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue)!
                context.draw(image, in: CGRect(x: 0, y: 0, width: image.width, height: image.height))
                let pixels = bytes.bindMemory(to: UInt8.self)
                var white = 0, mint = 0
                for index in stride(from: 0, to: pixels.count, by: 4) {
                    if pixels[index] > 200 && pixels[index + 1] > 200 && pixels[index + 2] > 200 { white += 1 }
                    if pixels[index] > 100 && Int(pixels[index + 1]) > Int(pixels[index]) + 20 && pixels[index + 1] > 200 && pixels[index + 2] < 230 { mint += 1 }
                }
                return (white, mint)
            }
            XCTAssertGreaterThan(textPixels.0, 100, "The exported frame should contain the burned-in white headline.")
            XCTAssertGreaterThan(textPixels.1, 30, "The exported frame should contain the timed mint caption.")
            print("PIPELINE: duration, aspect and burned text verified")
            let folder = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString + ".jpg")
            try await ProjectStore.thumbnail(video: output, at: 0.5, destination: folder)
            XCTAssertTrue(FileManager.default.fileExists(atPath: folder.path))
            try FileManager.default.removeItem(at: folder)
        }
    }
}
