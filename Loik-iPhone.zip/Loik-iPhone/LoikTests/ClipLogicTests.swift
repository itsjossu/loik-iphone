import XCTest
@testable import Loik

final class ClipLogicTests: XCTestCase {
    func testShortSourceIsNotExtendedBeyondItsEnd() {
        let clips = ClipLogic.suggestions(duration: 2.5)
        XCTAssertEqual(clips.count, 1)
        XCTAssertEqual(clips[0].start, 0)
        XCTAssertEqual(clips[0].end, 2.5)
    }

    func testLongSourceSuggestionsReachBothEndsAndStayInBounds() {
        let clips = ClipLogic.suggestions(duration: 3600)
        XCTAssertEqual(clips.count, 6)
        XCTAssertEqual(clips.first?.start, 0)
        XCTAssertEqual(clips.last?.end, 3600)
        for clip in clips {
            XCTAssertGreaterThanOrEqual(clip.start, 0)
            XCTAssertLessThanOrEqual(clip.end, 3600)
            XCTAssertEqual(clip.end - clip.start, 30, accuracy: 0.001)
        }
    }

    func testInvalidDurationsDoNotProduceClipRanges() {
        for duration in [0.0, -10.0, Double.nan, Double.infinity] {
            XCTAssertTrue(ClipLogic.suggestions(duration: duration).isEmpty)
        }
    }

    func testManualCaptionsPreserveWordsAndCoverSelectedDuration() {
        let text = "üks kaks kolm neli viis kuus seitse kaheksa üheksa kümme"
        let captions = ClipLogic.manualCaptions(text: text, duration: 17)
        XCTAssertEqual(captions.map(\.text).joined(separator: " "), text)
        XCTAssertEqual(captions.first?.start, 0)
        let last = captions.last!
        XCTAssertEqual(last.start + last.duration, 17, accuracy: 0.001)
        for pair in zip(captions, captions.dropFirst()) {
            XCTAssertEqual(pair.0.start + pair.0.duration, pair.1.start, accuracy: 0.001)
        }
    }

    func testEmptyCaptionsStayEmpty() {
        XCTAssertTrue(ClipLogic.manualCaptions(text: " \n ", duration: 10).isEmpty)
        XCTAssertTrue(ClipLogic.manualCaptions(text: "tere", duration: 0).isEmpty)
    }
}
