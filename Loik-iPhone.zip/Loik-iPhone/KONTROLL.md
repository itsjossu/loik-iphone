# Version 0.2 verification

Local static checks: Swift parser, Xcode project references, Info.plist, privacy manifest and workflow YAML.

CI must pass the simulator XCTest stage (including real video exports) and Release iPhoneOS build before an IPA is delivered. Phone installation, real-device speech availability and real-world highlight quality require device testing. Layout preview cards are labeled preview data; they are not generated from a real source video.
