# Version 0.2 verification

Pending revision: the current local source changes aspect fill to aspect fit with a softened backdrop, and fits overlay text to safe bounds. These changes have passed syntax parsing only; the previously delivered IPA does not contain them. Earlier CI results below apply to the recorded commits, not this pending revision.

Local static checks: Swift parser, Xcode project references, Info.plist, privacy manifest and workflow YAML.

All 11 simulator tests passed for source archive commit 6f68bfc8d88fca32d3be981f70dee7940cb8bd21 in run 41202013355. These cover audio RMS analysis, durable project storage, highlight ordering, overlap limits, caption timing and real portrait/square MP4 exports. Exported frames are checked for burned-in white headlines and mint captions as well as duration and aspect ratio.

Run 41202781879 repeated the tests successfully, compiled Release for iPhoneOS and packaged the IPA. The downloaded version 0.2.0 (2), bundle ID local.loik.editor, minimum iOS 17 and arm64 Mach-O executable were inspected; ZIP integrity passed. The screenshot step timed out independently and did not gate this build. A separate fresh-simulator workflow checks layouts.

Fresh-simulator layout run 41203330845 also passed. Projects, gallery and settings screenshots were downloaded and visually inspected. Layout preview cards use sample data; they are not generated from a real source video and are not enabled in normal launches.

Phone installation, real-device speech availability and real-world highlight quality require device testing.
