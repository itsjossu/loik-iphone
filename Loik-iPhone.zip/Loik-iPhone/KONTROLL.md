# Kontrolli seis

31.10.2026, Windowsi töökeskkond.

Läbitud:

- Kõigi 7 Swifti lähtekoodifaili süntaksi parsimine tree-sitter-swiftiga.
- Xcode’i projekti OpenStep-vormingu parsimine; mõlemad target’id olemas.
- Kõik projekti objektiviited lahenduvad ja kõik Swifti failid on projektis.
- Info.plist ja jagatud Xcode’i skeemi XML parsimine.
- Fotodesse lisamise ja kõnetuvastuse kasutusotstarbed on Info.plistis.
- GitHub Actionsi YAML parsimine; ainult käsitsi käivitus, standardne macOS-i
  runner ja avaliku hoidla kontroll.

Veel tegemata:

- Apple’i SDK-ga tüübikontroll ja Xcode’i build.
- Kaasasolevate 5 XCTest-testi käivitamine.
- iPhone’i simulaatoris kasutajaliidese kontroll.
- Päris videote eksport, heli, pööramise ja subtiitrite ajastuse kontroll.
- IPA loomine, allkirjastamine, AltStore’iga paigaldamine ja iPhone’is käivitamine.

Süntaksi kontroll ei kinnita, et projekt Apple’i kompilaatoriga ehitub või et
videotöötlus seadmes õigesti töötab. GitHubi töövoog teeb järgmisel etapil
kompileerimise ja XCTesti; seadmekontrolli sammud on failis ALUSTA-SIIST.md.
