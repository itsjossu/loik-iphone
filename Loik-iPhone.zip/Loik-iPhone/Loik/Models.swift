import Foundation
import CoreTransferable
import UniformTypeIdentifiers

struct ImportedMovie: Transferable {
    let url: URL
    static var transferRepresentation: some TransferRepresentation {
        FileRepresentation(contentType: .movie) { movie in
            SentTransferredFile(movie.url)
        } importing: { received in
            let suffix = received.file.pathExtension.isEmpty ? "mov" : received.file.pathExtension
            let target = FileManager.default.temporaryDirectory
                .appendingPathComponent(UUID().uuidString).appendingPathExtension(suffix)
            try FileManager.default.copyItem(at: received.file, to: target)
            return ImportedMovie(url: target)
        }
    }
}

struct Caption: Identifiable {
    let id = UUID()
    let start: Double
    let duration: Double
    var text: String
}

struct ClipRange: Identifiable {
    let id = UUID()
    let start: Double
    let end: Double
}

enum ClipLogic {
    // Spread useful starting points across the source; these are NOT semantic AI highlights.
    static func suggestions(duration: Double, length: Double = 30) -> [ClipRange] {
        guard duration.isFinite, duration > 0, length > 0 else { return [] }
        let count = min(6, max(1, Int(ceil(duration / length))))
        return (0..<count).map { index in
            let start = count == 1 ? 0 : (duration - min(length, duration)) * Double(index) / Double(count - 1)
            return ClipRange(start: start, end: min(duration, start + length))
        }
    }

    static func manualCaptions(text: String, duration: Double) -> [Caption] {
        let words = text.split(whereSeparator: \.isWhitespace).map(String.init)
        guard !words.isEmpty, duration > 0 else { return [] }
        let groups = stride(from: 0, to: words.count, by: 7).map {
            Array(words[$0..<min($0 + 7, words.count)]).joined(separator: " ")
        }
        return groups.enumerated().map { i, text in
            Caption(start: Double(i) * duration / Double(groups.count),
                    duration: duration / Double(groups.count), text: text)
        }
    }

    static func timestamp(_ seconds: Double) -> String {
        let value = max(0, Int(seconds.isFinite ? seconds : 0))
        return String(format: "%02d:%02d", value / 60, value % 60)
    }
}

enum LoikError: LocalizedError {
    case message(String)
    var errorDescription: String? {
        if case let .message(text) = self { return text }
        return nil
    }
}
