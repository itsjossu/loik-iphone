import AVFoundation
import UIKit

enum VideoEngine {
    static func performExport(_ session: AVAssetExportSession) async throws {
        await withTaskCancellationHandler {
            await withCheckedContinuation { (continuation: CheckedContinuation<Void, Never>) in
                session.exportAsynchronously { continuation.resume() }
            }
        } onCancel: { session.cancelExport() }
        try Task.checkCancellation()
        guard session.status == .completed else {
            throw session.error ?? LoikError.message("Video export failed.")
        }
    }

    static func audio(url: URL, start: Double, end: Double) async throws -> URL {
        let asset = AVURLAsset(url: url)
        guard !(try await asset.loadTracks(withMediaType: .audio)).isEmpty else {
            throw LoikError.message("This video has no audio track.")
        }
        guard let session = AVAssetExportSession(asset: asset, presetName: AVAssetExportPresetAppleM4A) else {
            throw LoikError.message("Audio could not be extracted from this video.")
        }
        let output = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString + ".m4a")
        session.outputURL = output
        session.outputFileType = .m4a
        session.timeRange = CMTimeRange(start: CMTime(seconds: start, preferredTimescale: 600),
                                       duration: CMTime(seconds: end - start, preferredTimescale: 600))
        do { try await performExport(session); return output }
        catch { try? FileManager.default.removeItem(at: output); throw error }
    }

    static func export(url: URL, start: Double, end: Double, vertical: Bool,
                       captions: [Caption], aspect: Double? = nil,
                       headline: String? = nil, style: CaptionStyle = .bold) async throws -> URL {
        let asset = AVURLAsset(url: url)
        let duration = try await asset.load(.duration).seconds
        guard start >= 0, end > start, end <= duration + 0.02 else {
            throw LoikError.message("Choose a valid clip start and end.")
        }
        guard let source = try await asset.loadTracks(withMediaType: .video).first else {
            throw LoikError.message("This file has no video track.")
        }
        let composition = AVMutableComposition()
        guard let videoTrack = composition.addMutableTrack(withMediaType: .video,
                                             preferredTrackID: kCMPersistentTrackID_Invalid) else {
            throw LoikError.message("Could not create a video track.")
        }
        let range = CMTimeRange(start: CMTime(seconds: start, preferredTimescale: 600),
                                duration: CMTime(seconds: end - start, preferredTimescale: 600))
        try videoTrack.insertTimeRange(range, of: source, at: .zero)
        // Preserve the first audio track, when one is present.
        let audioTracks = try await asset.loadTracks(withMediaType: .audio)
        if let sourceAudio = audioTracks.first {
            guard let audioTrack = composition.addMutableTrack(withMediaType: .audio,
                                                preferredTrackID: kCMPersistentTrackID_Invalid) else {
                throw LoikError.message("Could not create an audio track.")
            }
            let sourceRange = try await sourceAudio.load(.timeRange)
            let intersection = CMTimeRangeGetIntersection(range, otherRange: sourceRange)
            if intersection.duration.seconds > 0 {
                try audioTrack.insertTimeRange(intersection, of: sourceAudio,
                                              at: CMTimeSubtract(intersection.start, range.start))
            }
        }
        let size = try await source.load(.naturalSize)
        let preferred = try await source.load(.preferredTransform)
        let oriented = CGRect(origin: .zero, size: size).applying(preferred)
        let renderSize: CGSize
        if let aspect {
            let height = aspect > 1 ? 1080.0 / aspect : 1280.0
            renderSize = CGSize(width: floor(height * aspect / 2) * 2, height: floor(height / 2) * 2)
        } else if vertical {
            renderSize = CGSize(width: 1080, height: 1920)
        } else {
            // Bound resolution and use even dimensions for H.264.
            let ratio = min(1, 1920 / max(oriented.width, oriented.height))
            renderSize = CGSize(width: max(2, floor(oriented.width * ratio / 2) * 2),
                                height: max(2, floor(oriented.height * ratio / 2) * 2))
        }
        let scale = min(renderSize.width / oriented.width, renderSize.height / oriented.height)
        let transform = preferred
            .concatenating(CGAffineTransform(translationX: -oriented.minX, y: -oriented.minY))
            .concatenating(CGAffineTransform(scaleX: scale, y: scale))
            .concatenating(CGAffineTransform(translationX: (renderSize.width - oriented.width * scale) / 2,
                                            y: (renderSize.height - oriented.height * scale) / 2))
        let videoComposition = AVMutableVideoComposition()
        videoComposition.customVideoCompositorClass = CaptionCompositor.self
        videoComposition.renderSize = renderSize
        videoComposition.frameDuration = CMTime(value: 1, timescale: 30)
        videoComposition.instructions = [ClipInstruction(trackID: videoTrack.trackID, duration: range.duration,
            transform: transform, sourceSize: size, size: renderSize, captions: captions,
            headline: headline, style: style)]
        guard let session = AVAssetExportSession(asset: composition, presetName: AVAssetExportPresetHighestQuality) else {
            throw LoikError.message("This video could not be exported.")
        }
        let output = FileManager.default.temporaryDirectory.appendingPathComponent("Loik-" + UUID().uuidString + ".mp4")
        session.outputURL = output
        session.outputFileType = .mp4
        session.shouldOptimizeForNetworkUse = true
        session.videoComposition = videoComposition
        do { try await performExport(session); return output }
        catch { try? FileManager.default.removeItem(at: output); throw error }
    }
}
