import AVFoundation
import UIKit
import CoreText

enum VideoEngine {
    static func performExport(_ session: AVAssetExportSession) async throws {
        await withCheckedContinuation { (continuation: CheckedContinuation<Void, Never>) in
            session.exportAsynchronously { continuation.resume() }
        }
        guard session.status == .completed else {
            throw session.error ?? LoikError.message("Video eksportimine ebaõnnestus.")
        }
    }

    static func audio(url: URL, start: Double, end: Double) async throws -> URL {
        let asset = AVURLAsset(url: url)
        guard !(try await asset.loadTracks(withMediaType: .audio)).isEmpty else {
            throw LoikError.message("Selles videos ei ole helirada.")
        }
        guard let session = AVAssetExportSession(asset: asset, presetName: AVAssetExportPresetAppleM4A) else {
            throw LoikError.message("Heli ei saa sellest videost eraldada.")
        }
        let output = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString + ".m4a")
        session.outputURL = output
        session.outputFileType = .m4a
        session.timeRange = CMTimeRange(start: CMTime(seconds: start, preferredTimescale: 600),
                                       duration: CMTime(seconds: end - start, preferredTimescale: 600))
        do { try await performExport(session); return output }
        catch { try? FileManager.default.removeItem(at: output); throw error }
    }

    static func export(url: URL, start: Double, end: Double, vertical: Bool,
                       captions: [Caption]) async throws -> URL {
        let asset = AVURLAsset(url: url)
        let duration = try await asset.load(.duration).seconds
        guard start >= 0, end > start, end <= duration + 0.02 else {
            throw LoikError.message("Vali korrektne klipi algus ja lõpp.")
        }
        guard let source = try await asset.loadTracks(withMediaType: .video).first else {
            throw LoikError.message("Videoriba puudub.")
        }
        let composition = AVMutableComposition()
        guard let videoTrack = composition.addMutableTrack(withMediaType: .video,
                                             preferredTrackID: kCMPersistentTrackID_Invalid) else {
            throw LoikError.message("Videoriba loomine ebaõnnestus.")
        }
        let range = CMTimeRange(start: CMTime(seconds: start, preferredTimescale: 600),
                                duration: CMTime(seconds: end - start, preferredTimescale: 600))
        try videoTrack.insertTimeRange(range, of: source, at: .zero)
        // Preserve the first audio track, when one is present.
        let audioTracks = try await asset.loadTracks(withMediaType: .audio)
        if let sourceAudio = audioTracks.first {
            guard let audioTrack = composition.addMutableTrack(withMediaType: .audio,
                                                preferredTrackID: kCMPersistentTrackID_Invalid) else {
                throw LoikError.message("Heliriba loomine ebaõnnestus.")
            }
            let sourceRange = try await sourceAudio.load(.timeRange)
            let intersection = CMTimeRangeGetIntersection(range, otherRange: sourceRange)
            if intersection.duration.seconds > 0 {
                try audioTrack.insertTimeRange(intersection, of: sourceAudio,
                                              at: CMTimeSubtract(intersection.start, range.start))
            }
        }
        let size = try await source.load(.naturalSize)
        let preferred = try await source.load(.preferredTransform)
        let oriented = CGRect(origin: .zero, size: size).applying(preferred)
        let renderSize: CGSize
        if vertical {
            renderSize = CGSize(width: 1080, height: 1920)
        } else {
            // Bound resolution and use even dimensions for H.264.
            let ratio = min(1, 1920 / max(oriented.width, oriented.height))
            renderSize = CGSize(width: max(2, floor(oriented.width * ratio / 2) * 2),
                                height: max(2, floor(oriented.height * ratio / 2) * 2))
        }
        let scale = max(renderSize.width / oriented.width, renderSize.height / oriented.height)
        let transform = preferred
            .concatenating(CGAffineTransform(translationX: -oriented.minX, y: -oriented.minY))
            .concatenating(CGAffineTransform(scaleX: scale, y: scale))
            .concatenating(CGAffineTransform(translationX: (renderSize.width - oriented.width * scale) / 2,
                                            y: (renderSize.height - oriented.height * scale) / 2))
        let layerInstruction = AVMutableVideoCompositionLayerInstruction(assetTrack: videoTrack)
        layerInstruction.setTransform(transform, at: .zero)
        let instruction = AVMutableVideoCompositionInstruction()
        instruction.timeRange = CMTimeRange(start: .zero, duration: range.duration)
        instruction.layerInstructions = [layerInstruction]
        let videoComposition = AVMutableVideoComposition()
        videoComposition.renderSize = renderSize
        videoComposition.frameDuration = CMTime(value: 1, timescale: 30)
        videoComposition.instructions = [instruction]

        if !captions.isEmpty {
            let parent = CALayer()
            parent.frame = CGRect(origin: .zero, size: renderSize)
            let videoLayer = CALayer()
            videoLayer.frame = parent.bounds
            parent.addSublayer(videoLayer)
            let fontSize = renderSize.width * 0.050
            for caption in captions where caption.start < end - start && !caption.text.isEmpty {
                let label = CATextLayer()
                label.frame = CGRect(x: renderSize.width * 0.07, y: renderSize.height * 0.12,
                                     width: renderSize.width * 0.86, height: fontSize * 4.8)
                label.string = caption.text
                label.font = CTFontCreateWithName("Helvetica-Bold" as CFString, fontSize, nil)
                label.fontSize = fontSize
                label.alignmentMode = .center
                label.isWrapped = true
                label.foregroundColor = UIColor.white.cgColor
                label.backgroundColor = UIColor.black.withAlphaComponent(0.72).cgColor
                label.cornerRadius = 14
                label.contentsScale = 2
                label.opacity = 0
                let visible = CAKeyframeAnimation(keyPath: "opacity")
                visible.values = [0, 1, 1, 0]
                visible.keyTimes = [0, 0.001, 0.999, 1]
                visible.beginTime = AVCoreAnimationBeginTimeAtZero + caption.start
                visible.duration = min(caption.duration, end - start - caption.start)
                visible.isRemovedOnCompletion = false
                visible.fillMode = .both
                label.add(visible, forKey: "subtitle")
                parent.addSublayer(label)
            }
            videoComposition.animationTool = AVVideoCompositionCoreAnimationTool(
                postProcessingAsVideoLayer: videoLayer, in: parent)
        }
        guard let session = AVAssetExportSession(asset: composition, presetName: AVAssetExportPresetHighestQuality) else {
            throw LoikError.message("Seda videot ei saa eksportida.")
        }
        let output = FileManager.default.temporaryDirectory.appendingPathComponent("Loik-" + UUID().uuidString + ".mp4")
        session.outputURL = output
        session.outputFileType = .mp4
        session.shouldOptimizeForNetworkUse = true
        session.videoComposition = videoComposition
        do { try await performExport(session); return output }
        catch { try? FileManager.default.removeItem(at: output); throw error }
    }
}
