import SwiftUI
import PhotosUI
import AVFoundation

struct EditorView: View {
    @StateObject private var model = EditorModel()
    @State private var selected: PhotosPickerItem?
    @State private var files = false
    @State private var manualText = ""
    @State private var help = false
    private let mint = Color(red: 0.63, green: 1, blue: 0.48)

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 24) {
                    HStack {
                        Label("LÕIK", systemImage: "scissors").font(.title.bold())
                        Spacer()
                        Text("SINU VIDEO. SINU TELEFONIS.")
                            .font(.system(size: 9, weight: .bold, design: .monospaced)).foregroundStyle(mint)
                    }
                    if model.source == nil { introduction }
                    HStack {
                        PhotosPicker(selection: $selected, matching: .videos) {
                            Label("Vali video", systemImage: "photo.on.rectangle.angled")
                        }.buttonStyle(.borderedProminent).tint(mint).foregroundStyle(.black)
                        Button { files = true } label: { Label("Failidest", systemImage: "folder") }
                            .buttonStyle(.bordered)
                    }
                    if let player = model.player {
                        ZStack(alignment: .bottom) {
                            PlayerSurface(player: player, fill: model.vertical)
                            if !model.activeCaption.isEmpty {
                                Text(model.activeCaption).font(.system(size: 17, weight: .bold))
                                    .multilineTextAlignment(.center).padding(10)
                                    .background(.black.opacity(0.72), in: RoundedRectangle(cornerRadius: 8))
                                    .padding(.horizontal, 20).padding(.bottom, 35)
                                    .allowsHitTesting(false)
                            }
                        }
                        .aspectRatio(model.vertical ? 9.0 / 16.0 : model.originalAspect, contentMode: .fit)
                        .frame(maxHeight: 440).clipped().clipShape(RoundedRectangle(cornerRadius: 20))
                        .overlay(alignment: .topLeading) {
                            Text(model.vertical ? "9:16 · keskelt kärbitud" : "Algne formaat")
                                .font(.caption).padding(8).background(.black.opacity(0.7), in: Capsule()).padding(12)
                        }
                        HStack {
                            Button { model.play() } label: { Label("Esita / peata", systemImage: "playpause.fill") }
                            Spacer()
                            Text(ClipLogic.timestamp(model.currentTime)).monospacedDigit()
                        }
                        section("01", "Vali lõik") {
                            Text("Algus \(ClipLogic.timestamp(model.start))").monospacedDigit()
                            Slider(value: $model.start, in: 0...max(0.01, model.end - 0.25), step: 0.1)
                                .onChange(of: model.start) { _, _ in model.rangeChanged() }
                            Text("Lõpp \(ClipLogic.timestamp(model.end)) · \(model.length, specifier: "%.1f") s").monospacedDigit()
                            Slider(value: $model.end, in: min(model.duration, model.start + 0.25)...model.duration, step: 0.1)
                                .onChange(of: model.end) { _, _ in model.rangeChanged() }
                            Text("Valiku muutmine eemaldab senised subtiitrid.").font(.caption).foregroundStyle(.secondary)
                            ScrollView(.horizontal, showsIndicators: false) {
                                HStack {
                                    ForEach(ClipLogic.suggestions(duration: model.duration)) { clip in
                                        Button(ClipLogic.timestamp(clip.start) + "–" + ClipLogic.timestamp(clip.end)) {
                                            model.choose(clip)
                                        }.buttonStyle(.bordered)
                                    }
                                }
                            }
                            Text("Ühtlaselt jaotatud alguspunktid; sisu põhjal parimaid hetki see versioon ei vali.")
                                .font(.caption).foregroundStyle(.secondary)
                            Toggle("Püstvideo 9:16", isOn: $model.vertical)
                            Text("Püstformaat kärbib kaadri keskelt. Rääkija automaatset jälgimist veel pole.")
                                .font(.caption).foregroundStyle(.secondary)
                        }
                        section("02", "Lisa subtiitrid") {
                            Picker("Kõne keel", selection: $model.locale) {
                                Text("Inglise").tag("en-US")
                                Text("Eesti (kui toetatud)").tag("et-EE")
                                Text("Soome").tag("fi-FI")
                                Text("Vene").tag("ru-RU")
                                Text("Hispaania").tag("es-ES")
                            }
                            Button { Task { await model.transcribe() } } label: {
                                Label("Tuvasta kõne telefonis", systemImage: "waveform")
                            }.buttonStyle(.bordered).disabled(model.length > 55)
                            Text("Kuni 55 s. Keele tugi sõltub iPhone’ist ja paigaldatud keelemudelitest. Eesti keele tuge ei saa lubada.")
                                .font(.caption).foregroundStyle(.secondary)
                            TextField("Või kirjuta subtiitrite tekst…", text: $manualText, axis: .vertical)
                                .lineLimit(3...6).textFieldStyle(.roundedBorder)
                            Button("Jaota minu tekst klipi peale") { model.manual(manualText) }
                                .disabled(manualText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                            ForEach($model.captions) { $caption in
                                HStack(alignment: .top) {
                                    Text(ClipLogic.timestamp(caption.start)).font(.caption.monospacedDigit()).foregroundStyle(mint)
                                    TextField("Subtiiter", text: $caption.text, axis: .vertical)
                                        .textFieldStyle(.roundedBorder)
                                }
                            }
                            if !model.captions.isEmpty {
                                Button("Eemalda subtiitrid", role: .destructive) { model.captions = [] }
                            }
                        }
                        section("03", "Loo klipp") {
                            Button { Task { await model.export() } } label: {
                                Label("Loo MP4", systemImage: "square.and.arrow.up").frame(maxWidth: .infinity).padding(8)
                            }.buttonStyle(.borderedProminent).tint(mint).foregroundStyle(.black)
                            if model.exported != nil {
                                Text("Viimati loodud MP4. Pärast muudatusi vajuta uuesti „Loo MP4”.")
                                    .font(.caption).foregroundStyle(.secondary)
                                HStack {
                                    Button("Salvesta Fotodesse") { Task { await model.saveToPhotos() } }
                                    Spacer()
                                    Button("Jaga…") { model.share = true }
                                }
                            }
                            Text("Ilma vesimärgi ja tellimuseta. Hoia eksportimise ajal rakendus avatuna.")
                                .font(.caption).foregroundStyle(.secondary)
                        }
                    }
                    if !model.status.isEmpty {
                        HStack {
                            if model.busy { ProgressView() }
                            Text(model.status).font(.footnote)
                        }.padding().frame(maxWidth: .infinity, alignment: .leading)
                            .background(.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 14))
                    }
                    Text("LÕIK · ESIMENE VERSIOON").font(.caption2.monospaced()).foregroundStyle(.secondary)
                }.padding(20).disabled(model.busy)
            }
            .background(Color(red: 0.045, green: 0.065, blue: 0.055))
            .tint(mint)
            .toolbar { Button { help = true } label: { Image(systemName: "info.circle") } }
            .sheet(isPresented: $help) { helpView }
            .sheet(isPresented: $model.share) {
                if let url = model.exported { ShareSheet(url: url) }
            }
            .alert("Teade", isPresented: Binding(get: { model.error != nil }, set: { if !$0 { model.error = nil } })) {
                Button("Selge") { model.error = nil }
            } message: { Text(model.error ?? "") }
            .onChange(of: selected) { _, item in
                if let item { Task { await model.importPhoto(item); selected = nil } }
            }
            .fileImporter(isPresented: $files, allowedContentTypes: [.movie]) { result in
                switch result {
                case .success(let url): Task { await model.importFile(url) }
                case .failure(let error): model.error = error.localizedDescription
                }
            }
        }
    }

    private var introduction: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text("Pikast videost.\nSinu järgmine klipp.")
                .font(.system(size: 38, weight: .bold, design: .rounded)).tracking(-1)
            Text("Vali video, lõika sobiv hetk ja lisa subtiitrid. Kõik sinu iPhone’is.")
                .foregroundStyle(.secondary)
            HStack(spacing: 18) {
                Label("9:16", systemImage: "iphone")
                Label("MP4", systemImage: "film")
                Label("0 €", systemImage: "checkmark.seal")
            }.font(.caption.bold()).foregroundStyle(mint)
        }.padding(.vertical, 20)
    }

    private func section<Content: View>(_ number: String, _ title: String,
                                       @ViewBuilder content: () -> Content) -> some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                Text(number).font(.caption.monospaced()).foregroundStyle(mint)
                Text(title).font(.title3.bold())
            }
            content()
        }.padding(18).background(.white.opacity(0.045), in: RoundedRectangle(cornerRadius: 20))
    }

    private var helpView: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    Text("Sinu video jääb sinu seadmesse.").font(.title2.bold())
                    Text("Lõik ei kasuta tasulisi API-sid, kasutajakontot ega meie serverit. Fotode valija võib iCloudis oleva video Apple’ilt alla laadida. Kõnetuvastus töötab ainult siis, kui valitud keel on seadmes toetatud; võrgupõhist varuvarianti ei kasutata.")
                    Text("See on eraldi rakenduse esimene versioon. Siin pole OpusClipi sisupõhist klipivalikut, kõneleja jälgimist, videolingist importimist ega automaatset sotsiaalmeediasse postitamist.")
                    Text("Kõnetuvastuse tekst võib sisaldada vigu. Kontrolli teksti ja lõplikku videot. Käsitsi lisatud teksti ajastus on ühtlane, mitte kõnepõhine.")
                    Text("Projekt ei säili pärast rakenduse sulgemist. Salvesta vajalik MP4 enne sulgemist. Pikkade videote import ja eksport vajavad vaba salvestusruumi.")
                }.padding()
            }.navigationTitle("Rakendusest")
                .toolbar { Button("Valmis") { help = false } }
        }
    }
}

private struct PlayerSurface: UIViewRepresentable {
    let player: AVPlayer
    let fill: Bool
    final class Surface: UIView {
        override class var layerClass: AnyClass { AVPlayerLayer.self }
        var videoLayer: AVPlayerLayer { layer as! AVPlayerLayer }
    }
    func makeUIView(context: Context) -> Surface { Surface() }
    func updateUIView(_ view: Surface, context: Context) {
        view.videoLayer.player = player
        view.videoLayer.videoGravity = fill ? .resizeAspectFill : .resizeAspect
    }
}

private struct ShareSheet: UIViewControllerRepresentable {
    let url: URL
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: [url], applicationActivities: nil)
    }
    func updateUIViewController(_ controller: UIActivityViewController, context: Context) {}
}
