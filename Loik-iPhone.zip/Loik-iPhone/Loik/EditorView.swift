import SwiftUI
import PhotosUI
import AVKit

private let accent = Color(red: 0.75, green: 0.98, blue: 0.46)

struct AuroraBackground: View {
    var body: some View {
        GeometryReader { geometry in
            ZStack {
                Color(red: 0.055, green: 0.06, blue: 0.09)
                Ellipse().fill(Color.cyan.opacity(0.34)).frame(width: 230, height: geometry.size.height * 0.8)
                    .blur(radius: 70).rotationEffect(.degrees(20)).offset(x: 30, y: -100)
                Ellipse().fill(Color.teal.opacity(0.4)).frame(width: 180, height: 440)
                    .blur(radius: 65).offset(x: 40, y: 330)
                Ellipse().fill(Color.purple.opacity(0.22)).frame(width: 260, height: 420)
                    .blur(radius: 65).offset(x: 210, y: 270)
            }.frame(maxWidth: .infinity, maxHeight: .infinity)
        }.ignoresSafeArea()
    }
}

extension View {
    func glass(_ radius: CGFloat = 22) -> some View {
        self.background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: radius))
            .overlay(RoundedRectangle(cornerRadius: radius).stroke(.white.opacity(0.18), lineWidth: 0.7))
    }
}

struct LocalThumbnail: View {
    let url: URL
    var body: some View {
        GeometryReader { geometry in
            if let image = UIImage(contentsOfFile: url.path) {
                Image(uiImage: image).resizable().scaledToFill()
                    .frame(width: geometry.size.width, height: geometry.size.height).clipped()
            } else {
                ZStack {
                    LinearGradient(colors: [.teal.opacity(0.7), .indigo.opacity(0.5), .black], startPoint: .topLeading, endPoint: .bottomTrailing)
                    Image(systemName: "play.rectangle").font(.largeTitle).foregroundStyle(.white.opacity(0.65))
                }
            }
        }
    }
}

struct EditorView: View {
    @StateObject private var model = EditorModel()
    @State private var selected: PhotosPickerItem?
    @State private var importSheet = false
    @State private var files = false
    @State private var queueFilePicker = false
    @State private var help = false
    @State private var previewClip: GeneratedClip?
    @State private var sortByScore = true
    @State private var renameTitle = ""
    @State private var renaming = false
    @State private var deleting: VideoProject?
    @State private var youtubeLink = ""
    @State private var queueYouTube = false

    var body: some View {
        NavigationStack {
            ZStack {
                AuroraBackground()
                ScrollView {
                    VStack(alignment: .leading, spacing: 22) {
                        if let project = model.project { gallery(project) }
                        else { library }
                        if !model.status.isEmpty {
                            VStack(alignment: .leading, spacing: 10) {
                                HStack {
                                    if model.busy { ProgressView().tint(.white) }
                                    Text(model.status).font(.footnote)
                                    Spacer()
                                    if model.canStop { Button("Stop") { model.cancel() }.font(.footnote.bold()) }
                                }
                                if model.busy { ProgressView(value: model.progress).tint(accent) }
                            }.padding(16).glass(18)
                        }
                    }.padding(.horizontal, 20).padding(.top, 12).padding(.bottom, 100)
                }
            }
            .safeAreaInset(edge: .bottom, spacing: 0) { bottomBar.padding(.bottom, 8) }
            .toolbar(.hidden, for: .navigationBar)
            .tint(.white)
            .sheet(isPresented: $importSheet, onDismiss: {
                if let selected { self.selected = nil; Task { await model.importPhoto(selected) } }
                if queueFilePicker { queueFilePicker = false; files = true }
                if queueYouTube { queueYouTube = false; model.importYouTube(youtubeLink) }
            }) { importPanel }
            .onChange(of: selected) { _, item in if item != nil { importSheet = false } }
            .sheet(isPresented: $model.showSettings) { SettingsPanel(model: model) }
            .sheet(item: $previewClip) { clip in
                if let project = model.project { ClipPreview(clip: clip, project: project, model: model) }
            }
            .sheet(isPresented: $model.showShare) { ActivitySheet(urls: model.shareURLs) }
            .sheet(isPresented: $help) { helpPanel }
            .fileImporter(isPresented: $files, allowedContentTypes: [.movie]) { result in
                switch result {
                case .success(let url): Task { await model.importFile(url) }
                case .failure(let error): model.error = error.localizedDescription
                }
            }
            .alert("Something needs your attention", isPresented: Binding(get: { model.error != nil }, set: { if !$0 { model.error = nil } })) {
                Button("OK") { model.error = nil }
            } message: { Text(model.error ?? "") }
            .alert("Project name", isPresented: $renaming) {
                TextField("Project name", text: $renameTitle)
                Button("Save") { if let project = model.project { model.rename(project, title: renameTitle) } }
                Button("Cancel", role: .cancel) {}
            }
            .confirmationDialog("Delete this project and its local videos?", isPresented: Binding(
                get: { deleting != nil }, set: { if !$0 { deleting = nil } }), titleVisibility: .visible) {
                    if let deleting { Button("Delete project", role: .destructive) { model.remove(deleting) } }
                    Button("Cancel", role: .cancel) { deleting = nil }
            }
        }
    }

    private var library: some View {
        VStack(alignment: .leading, spacing: 26) {
            HStack(alignment: .top) {
                VStack(alignment: .leading, spacing: 4) {
                    Text("Projects").font(.system(size: 32, weight: .bold))
                    Text("All projects ›").font(.subheadline).foregroundStyle(.white.opacity(0.6))
                }
                Spacer()
                Label("Free", systemImage: "sparkles").font(.subheadline).padding(.horizontal, 14).padding(.vertical, 10).glass(30)
            }
            if model.projects.isEmpty {
                VStack(alignment: .leading, spacing: 18) {
                    Image(systemName: "rectangle.stack.badge.play.fill").font(.system(size: 42)).foregroundStyle(accent)
                    Text("Your next great clip\nstarts here.").font(.system(size: 29, weight: .semibold))
                    Text("Add a video. Find its strongest moments. Create a whole set of clips in one go.")
                        .foregroundStyle(.white.opacity(0.66))
                    Button { importSheet = true } label: {
                        Label("New project", systemImage: "plus").font(.headline).frame(maxWidth: .infinity).padding(16)
                    }.background(.white, in: Capsule()).foregroundStyle(.black).disabled(model.busy)
                }.padding(24).glass(28).padding(.top, 45)
            } else {
                LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], alignment: .leading, spacing: 24) {
                    ForEach(model.projects) { project in
                        Button { model.select(project) } label: {
                            VStack(alignment: .leading, spacing: 8) {
                                LocalThumbnail(url: ProjectStore.url(project, project.cover))
                                    .frame(height: 110).clipShape(RoundedRectangle(cornerRadius: 12))
                                    .overlay(alignment: .bottomLeading) {
                                        Text(project.clips.isEmpty ? "Ready to clip" : "\(project.clips.count) clips")
                                            .font(.caption2).padding(6).background(.black.opacity(0.6), in: Capsule()).padding(6)
                                    }
                                Text(project.title).font(.subheadline).lineLimit(2)
                                Text(project.created, style: .relative).font(.caption).foregroundStyle(.white.opacity(0.45))
                            }.frame(maxWidth: .infinity, alignment: .leading)
                        }.buttonStyle(.plain).disabled(model.busy)
                    }
                }
            }
        }
    }

    private func gallery(_ project: VideoProject) -> some View {
        VStack(alignment: .leading, spacing: 20) {
            HStack {
                Button { model.selectedID = nil } label: { Image(systemName: "chevron.left").padding(11).glass(30) }
                    .disabled(model.busy)
                Spacer()
                Menu {
                    Button(sortByScore ? "Sort by source time" : "Sort by rating") { sortByScore.toggle() }
                    Button("Rename project") { renameTitle = project.title; renaming = true }
                    Button("Create more clips") { model.showSettings = true }
                    if !project.clips.isEmpty {
                        Button("Save all to Photos") { Task { await model.save(project.clips, project: project) } }
                        Button("Share all clips") { model.share(project.clips, project: project) }
                    }
                    Button("Delete project", role: .destructive) { deleting = project }
                } label: { Image(systemName: "line.3.horizontal.decrease").padding(11).glass(30) }.disabled(model.busy)
            }
            Text(project.title).font(.system(size: 23, weight: .bold)).lineLimit(2)
            HStack {
                Text("\(project.clips.count) clips").font(.caption).foregroundStyle(.white.opacity(0.6))
                Spacer()
                Text("\(Image(systemName: "sparkles")) Highlight rating").font(.caption).foregroundStyle(accent)
            }
            if project.clips.isEmpty {
                LocalThumbnail(url: ProjectStore.url(project, project.cover)).frame(height: 210).clipShape(RoundedRectangle(cornerRadius: 20))
                Text("Turn this video into your next set of highlights.").font(.title3.weight(.medium))
                Button { model.showSettings = true } label: {
                    Text("Get clips in 1 click").font(.headline).frame(maxWidth: .infinity).padding(16)
                }.background(.white, in: Capsule()).foregroundStyle(.black).disabled(model.busy)
            } else {
                let clips = sortByScore ? project.clips.sorted { $0.score > $1.score } : project.clips.sorted { $0.start < $1.start }
                LazyVGrid(columns: [GridItem(.flexible(), spacing: 10), GridItem(.flexible(), spacing: 10)], spacing: 20) {
                    ForEach(clips) { clip in
                        Button { previewClip = clip } label: { ClipCard(clip: clip, project: project) }
                            .buttonStyle(.plain).disabled(model.busy)
                    }
                }
                Text(project.note).font(.caption).foregroundStyle(.white.opacity(0.55)).fixedSize(horizontal: false, vertical: true)
                Text("Ratings compare speech hooks, pacing, boundaries and audio activity. They are estimates, not predictions of views.")
                    .font(.caption2).foregroundStyle(.white.opacity(0.42))
            }
        }
    }

    private var bottomBar: some View {
        HStack(spacing: 24) {
            Button { if !model.busy { model.selectedID = nil } } label: {
                Image(systemName: "play.rectangle.fill").frame(width: 52, height: 42)
                    .background(.white.opacity(0.12), in: Capsule())
            }.accessibilityLabel("Projects")
            Button { importSheet = true } label: { Image(systemName: "plus").font(.system(size: 26, weight: .light)).frame(width: 44, height: 42) }
                .accessibilityLabel("Import video").disabled(model.busy)
            Button { help = true } label: { Image(systemName: "person.crop.circle").font(.title3).frame(width: 44, height: 42) }
                .accessibilityLabel("About and privacy")
        }.padding(7).glass(40)
    }

    private var importPanel: some View {
        VStack(alignment: .leading, spacing: 18) {
            Capsule().fill(.white.opacity(0.3)).frame(width: 34, height: 5).frame(maxWidth: .infinity)
            Text("New project").font(.title2.bold())
            TextField("Paste a YouTube link", text: $youtubeLink)
                .textInputAutocapitalization(.never).autocorrectionDisabled().keyboardType(.URL)
                .padding(14).glass(25)
            Button {
                queueYouTube = true; importSheet = false
            } label: { Label("Import from YouTube", systemImage: "link").frame(maxWidth: .infinity).padding(12).glass(25) }
                .disabled(YouTubeImport.videoID(youtubeLink) == nil)
            Text("Import videos you own or have permission to use. Public videos only; some links may be unavailable.")
                .font(.caption).foregroundStyle(.secondary)
            HStack(spacing: 12) {
                PhotosPicker(selection: $selected, matching: .videos) {
                    Label("Photo Library", systemImage: "photo.on.rectangle").frame(maxWidth: .infinity).padding(14).glass(30)
                }
                Button { queueFilePicker = true; importSheet = false } label: {
                    Label("Files", systemImage: "folder").frame(maxWidth: .infinity).padding(14).glass(30)
                }
            }
            Text("Local processing · No credits · No watermark").font(.caption).foregroundStyle(.secondary)
        }.padding(24).presentationDetents([.large]).presentationBackground(.ultraThinMaterial)
    }

    private var helpPanel: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    Text("Your video. Your iPhone.").font(.largeTitle.bold())
                    Text("Lõik 0.3 · Free local clipping").foregroundStyle(accent)
                    Text("Projects and finished clips stay in the app until you delete them. Source videos and clips use your iPhone’s storage. Export important clips to Photos or Files before uninstalling the app.")
                    Text("Smart highlights compare transcript openings, speaking pace, sentence boundaries and audio activity. A high rating is an editorial signal, not a promise of virality. Audio-only analysis is used when local speech recognition is unavailable.")
                    Text("Speech language support depends on your device and installed models. Your video is not sent to our server. The Photos picker may download originals from your iCloud library. Keep this app open during processing; long videos can take a while.")
                    Text("The full video frame is preserved with a softened background. YouTube imports run on your iPhone and require an internet connection. Restricted videos and some links may be unavailable. Speaker tracking is not included.")
                }.padding(24)
            }.navigationTitle("About Lõik").toolbar { Button("Done") { help = false } }
        }.presentationBackground(.ultraThinMaterial)
    }
}

struct ClipCard: View {
    let clip: GeneratedClip
    let project: VideoProject
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            LocalThumbnail(url: ProjectStore.url(project, clip.thumbnail))
                .aspectRatio(9.0 / 16, contentMode: .fit)
                .overlay(alignment: .topTrailing) {
                    Text(ClipLogic.timestamp(clip.duration)).font(.caption2.monospacedDigit())
                        .padding(.horizontal, 7).padding(.vertical, 4).background(.black.opacity(0.65), in: Capsule()).padding(6)
                }
                .overlay(alignment: .center) { Image(systemName: "play.fill").font(.title3).padding(14).background(.black.opacity(0.2), in: Circle()) }
                .clipShape(RoundedRectangle(cornerRadius: 12))
                .overlay(RoundedRectangle(cornerRadius: 12).stroke(.white.opacity(0.25), lineWidth: 0.8))
            HStack(alignment: .top, spacing: 5) {
                Text(clip.title).font(.system(size: 11, weight: .medium)).lineLimit(2).frame(maxWidth: .infinity, alignment: .leading)
                Text("\(clip.score)").font(.system(size: 18, weight: .bold, design: .rounded)).foregroundStyle(accent)
            }
        }.accessibilityElement(children: .combine).accessibilityLabel("\(clip.title), rating \(clip.score) out of 100")
    }
}

struct SettingsPanel: View {
    @ObservedObject var model: EditorModel
    @Environment(\.dismiss) private var dismiss
    @State private var saved = false
    var body: some View {
        NavigationStack {
            ZStack {
                AuroraBackground()
                ScrollView {
                    VStack(alignment: .leading, spacing: 24) {
                        if let project = model.project {
                            HStack(spacing: 14) {
                                LocalThumbnail(url: ProjectStore.url(project, project.cover)).frame(width: 105, height: 70).clipShape(RoundedRectangle(cornerRadius: 10))
                                VStack(alignment: .leading, spacing: 6) {
                                    Text(ClipLogic.timestamp(project.duration)).font(.caption).foregroundStyle(.secondary)
                                    Text(project.title).font(.subheadline.weight(.medium)).lineLimit(2)
                                    Text("Stored on your iPhone").font(.caption2).foregroundStyle(.secondary)
                                }
                            }
                        }
                        VStack(spacing: 0) {
                            HStack { Text("Video length"); Spacer(); Text("Full video").foregroundStyle(.secondary) }.padding(14)
                            Divider().overlay(.white.opacity(0.1))
                            Toggle("Smart speech ranking", isOn: $model.settings.useSpeech).padding(14)
                            Divider().overlay(.white.opacity(0.1))
                            Picker("Clip length", selection: $model.settings.length) {
                                Text("15 seconds").tag(15.0); Text("30 seconds").tag(30.0)
                                Text("45 seconds").tag(45.0); Text("60 seconds").tag(60.0)
                            }.padding(.horizontal, 14).padding(.vertical, 6)
                            Divider().overlay(.white.opacity(0.1))
                            Picker("Number of clips", selection: $model.settings.count) {
                                ForEach([2, 4, 6, 8], id: \.self) { Text("\($0) clips").tag($0) }
                            }.padding(.horizontal, 14).padding(.vertical, 6)
                            Divider().overlay(.white.opacity(0.1))
                            Toggle("Auto headline", isOn: $model.settings.headline).padding(14)
                            Divider().overlay(.white.opacity(0.1))
                            Toggle("Auto captions", isOn: $model.settings.subtitles).padding(14)
                            Divider().overlay(.white.opacity(0.1))
                            Picker("Speech language", selection: $model.settings.locale) {
                                Text("English").tag("en-US"); Text("Spanish").tag("es-ES")
                                Text("French").tag("fr-FR"); Text("German").tag("de-DE")
                                Text("Russian").tag("ru-RU"); Text("Estonian (if supported)").tag("et-EE")
                            }.padding(.horizontal, 14).padding(.vertical, 6)
                        }.glass(18)
                        VStack(alignment: .leading, spacing: 12) {
                            Text("ASPECT RATIO").font(.caption).foregroundStyle(.white.opacity(0.5))
                            HStack(spacing: 0) {
                                ForEach(Aspect.allCases) { aspect in
                                    Button { model.settings.aspect = aspect } label: {
                                        VStack(spacing: 10) {
                                            Image(systemName: aspect == .portrait ? "rectangle.portrait" : aspect == .square ? "square" : "rectangle")
                                                .font(.system(size: 27, weight: .light))
                                            Text(aspect.rawValue).font(.caption.bold()).padding(.horizontal, 8).padding(.vertical, 4)
                                                .background(model.settings.aspect == aspect ? .white : .clear, in: Capsule())
                                                .foregroundStyle(model.settings.aspect == aspect ? .black : .white.opacity(0.6))
                                        }.frame(maxWidth: .infinity).padding(.vertical, 17)
                                    }.buttonStyle(.plain)
                                }
                            }.glass(16)
                        }
                        VStack(alignment: .leading, spacing: 12) {
                            Text("QUICK PRESETS").font(.caption).foregroundStyle(.white.opacity(0.5))
                            HStack(spacing: 10) {
                                ForEach(CaptionStyle.allCases) { style in
                                    Button { model.settings.style = style } label: {
                                        VStack(spacing: 12) {
                                            Text("YOUR STORY").font(.system(size: 11, weight: .heavy, design: .rounded))
                                                .foregroundStyle(style == .mint ? accent : .white)
                                            Text(style.rawValue).font(.caption2)
                                        }.frame(maxWidth: .infinity).padding(.vertical, 22)
                                            .background(.white.opacity(model.settings.style == style ? 0.18 : 0.06), in: RoundedRectangle(cornerRadius: 12))
                                            .overlay(RoundedRectangle(cornerRadius: 12).stroke(.white.opacity(model.settings.style == style ? 0.6 : 0.1)))
                                    }.buttonStyle(.plain)
                                }
                            }
                        }
                        Text("On-device speech depends on language support. If unavailable, clips use audio activity and have no automatic captions. Short videos may produce fewer distinct clips.")
                            .font(.caption).foregroundStyle(.white.opacity(0.55))
                    }.padding(20).padding(.bottom, 20)
                }
            }
            .navigationTitle("Create clips").navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) { Button(saved ? "Saved ✓" : "Save as default") { model.saveDefaults(); saved = true }.font(.caption) }
            }
            .safeAreaInset(edge: .bottom) {
                VStack(spacing: 10) {
                    HStack { Text("Local processing"); Spacer(); Text("Free · No credits").foregroundStyle(accent) }.font(.caption)
                    Button { model.generate() } label: { Text("Get clips in 1 click").font(.headline).frame(maxWidth: .infinity).padding(16) }
                        .foregroundStyle(.black).background(.white, in: Capsule()).disabled(model.busy)
                }.padding(20).background(.ultraThinMaterial)
            }
        }.tint(.white)
    }
}

struct ClipPreview: View {
    let clip: GeneratedClip
    let project: VideoProject
    @ObservedObject var model: EditorModel
    @Environment(\.dismiss) private var dismiss
    @State private var player: AVPlayer?
    @State private var sharing = false
    var body: some View {
        NavigationStack {
            ZStack {
                AuroraBackground()
                ScrollView {
                    VStack(alignment: .leading, spacing: 18) {
                        if let player { VideoPlayer(player: player).aspectRatio(clip.aspect.ratio, contentMode: .fit).frame(maxHeight: 480).clipShape(RoundedRectangle(cornerRadius: 18)) }
                        HStack(alignment: .top) {
                            Text(clip.title).font(.title3.bold())
                            Spacer()
                            Text("\(clip.score)").font(.system(size: 36, weight: .bold, design: .rounded)).foregroundStyle(accent)
                        }
                        Text("\(ClipLogic.timestamp(clip.start)) – \(ClipLogic.timestamp(clip.end)) · \(clip.analysis)")
                            .font(.caption).foregroundStyle(.secondary)
                        VStack(alignment: .leading, spacing: 8) {
                            Text("Why this moment").font(.headline)
                            ForEach(clip.reasons, id: \.self) { Label($0, systemImage: "checkmark.circle").font(.subheadline) }
                            Text("Editorial rating out of 100. Not a prediction of views.").font(.caption).foregroundStyle(.secondary)
                        }.padding(18).glass(18)
                        HStack {
                            Button { Task { await model.save([clip], project: project) } } label: {
                                Label("Save video", systemImage: "square.and.arrow.down").frame(maxWidth: .infinity).padding(14).glass(30)
                            }.disabled(model.busy)
                            Button { sharing = true } label: {
                                Label("Share", systemImage: "square.and.arrow.up").frame(maxWidth: .infinity).padding(14).glass(30)
                            }
                        }
                        if !model.status.isEmpty { Text(model.status).font(.caption).foregroundStyle(.secondary) }
                    }.padding(20)
                }
            }.navigationTitle("Clip preview").navigationBarTitleDisplayMode(.inline)
                .toolbar { Button("Done") { dismiss() } }
                .onAppear { player = AVPlayer(url: ProjectStore.url(project, clip.file)); player?.play() }
                .onDisappear { player?.pause(); player = nil }
                .sheet(isPresented: $sharing) { ActivitySheet(urls: [ProjectStore.url(project, clip.file)]) }
        }.tint(.white)
    }
}

struct ActivitySheet: UIViewControllerRepresentable {
    let urls: [URL]
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: urls, applicationActivities: nil)
    }
    func updateUIViewController(_ controller: UIActivityViewController, context: Context) {}
}
