import SwiftUI

struct DiscoverCreator: Identifiable, Sendable {
    let id: String
    let name: String
    let topic: String
    let tag: String
    static let all = [
        DiscoverCreator(id: "UCHnyfMqiRRG1u-2MsSQLbXA", name: "Veritasium", topic: "Science", tag: "Veritasium"),
        DiscoverCreator(id: "UCBJycsmduvYEL83R_U4JriQ", name: "Marques Brownlee", topic: "Tech", tag: "MKBHD"),
        DiscoverCreator(id: "UCGq-a57w-aPwyi3pW7XLiHw", name: "The Diary Of A CEO", topic: "Podcast", tag: "DiaryOfACEO")
    ]
}

struct DiscoveryVideo: Identifiable, Codable, Sendable {
    let id: String
    let title: String
    let creatorID: String
    let creator: String
    let published: Date
    let views: Int?
    let fetched: Date
    var url: URL { URL(string: "https://www.youtube.com/watch?v=" + id)! }
    var thumbnail: URL { URL(string: "https://i.ytimg.com/vi/" + id + "/hqdefault.jpg")! }
}

final class VideoFeedParser: NSObject, XMLParserDelegate {
    private var videos: [DiscoveryVideo] = []
    private var inside = false
    private var element = ""
    private var identifier = "", title = "", published = ""
    private var views: Int?
    private let creator: DiscoverCreator
    private let fetched: Date
    init(creator: DiscoverCreator, fetched: Date) { self.creator = creator; self.fetched = fetched }
    static func parse(_ data: Data, creator: DiscoverCreator, fetched: Date) throws -> [DiscoveryVideo] {
        let delegate = VideoFeedParser(creator: creator, fetched: fetched)
        let parser = XMLParser(data: data)
        parser.shouldResolveExternalEntities = false
        parser.delegate = delegate
        guard parser.parse() else { throw LoikError.message("The channel feed could not be read.") }
        return delegate.videos
    }
    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes: [String: String]) {
        element = elementName
        if elementName == "entry" { inside = true; identifier = ""; title = ""; published = ""; views = nil }
        if inside && elementName == "media:statistics" { views = attributes["views"].flatMap(Int.init) }
    }
    func parser(_ parser: XMLParser, foundCharacters string: String) {
        guard inside else { return }
        switch element {
        case "yt:videoId": identifier += string
        case "title": title += string
        case "published": published += string
        default: break
        }
    }
    func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?) {
        if elementName == "entry" {
            let id = identifier.trimmingCharacters(in: .whitespacesAndNewlines)
            let name = title.trimmingCharacters(in: .whitespacesAndNewlines)
            if YouTubeImport.videoID("https://youtu.be/" + id) != nil, !name.isEmpty,
               let date = ISO8601DateFormatter().date(from: published.trimmingCharacters(in: .whitespacesAndNewlines)) {
                videos.append(DiscoveryVideo(id: id, title: name, creatorID: creator.id, creator: creator.name,
                    published: date, views: views, fetched: fetched))
            }
            inside = false
        }
        element = ""
    }
}

enum DiscoverySignals {
    static func hourlyViews(_ video: DiscoveryVideo) -> Double? {
        guard let views = video.views, views >= 0 else { return nil }
        return Double(views) / max(3, video.fetched.timeIntervalSince(video.published) / 3600)
    }
    static func relativePace(_ video: DiscoveryVideo, among videos: [DiscoveryVideo]) -> Double? {
        let peers = videos.filter { $0.creatorID == video.creatorID && $0.id != video.id }.compactMap(hourlyViews).filter { $0 > 0 }.sorted()
        guard peers.count >= 3, let pace = hourlyViews(video) else { return nil }
        return pace / peers[peers.count / 2]
    }
    static func score(_ video: DiscoveryVideo, among videos: [DiscoveryVideo]) -> Int {
        let freshness = max(0, 1 - max(0, video.fetched.timeIntervalSince(video.published)) / (14 * 86400))
        let tokens = Set(HighlightScorer.words(video.title))
        let hooks: Set<String> = ["why", "how", "mistake", "never", "secret", "happens", "unexpected", "first"]
        let opening = min(10, tokens.intersection(hooks).count * 3)
        let pace = relativePace(video, among: videos).map { max(-25, min(35, log2(max(0.01, $0)) * 15)) } ?? 0
        return max(1, min(99, Int((40 + freshness * 15 + pace).rounded()) + opening))
    }
    static func tags(_ video: DiscoveryVideo) -> String {
        let creator = DiscoverCreator.all.first { $0.id == video.creatorID }
        var tags = ["#" + (creator?.tag ?? "VideoClips")]
        let text = video.title.lowercased()
        if text.contains("iphone") { tags += ["#iPhone", "#Apple"] }
        else if text.contains("macbook") { tags += ["#MacBook", "#Tech"] }
        else if text.contains("apple") { tags += ["#Apple", "#Tech"] }
        else if creator?.topic == "Science" { tags += ["#Science", "#LearnSomethingNew"] }
        else if creator?.topic == "Podcast" { tags += ["#PodcastClips", "#Interview"] }
        else { tags += ["#Tech", "#Gadgets"] }
        return (tags + ["#Shorts"]).joined(separator: " ")
    }
    static func angle(_ video: DiscoveryVideo) -> String {
        switch DiscoverCreator.all.first(where: { $0.id == video.creatorID })?.topic {
        case "Science": return "Look for one surprising demonstration and its explanation. Keep the reveal and enough context to understand it."
        case "Tech": return "Look for a visual comparison, unexpected result or a clear verdict. Include the reason behind the opinion."
        default: return "Look for a complete question and a concrete answer, story or practical takeaway. Avoid quotes that change meaning without context."
        }
    }
}

@MainActor final class DiscoverModel: ObservableObject {
    @Published var videos: [DiscoveryVideo] = []
    @Published var loading = false
    @Published var message = ""
    init() {
        if let data = UserDefaults.standard.data(forKey: "discoveryCache"),
           let saved = try? JSONDecoder().decode([DiscoveryVideo].self, from: data) { videos = saved }
    }
    func refresh() async {
        guard !loading else { return }
        loading = true
        defer { loading = false }
        let configuration = URLSessionConfiguration.ephemeral
        configuration.timeoutIntervalForRequest = 15; configuration.timeoutIntervalForResource = 25
        let session = URLSession(configuration: configuration)
        defer { session.invalidateAndCancel() }
        let now = Date()
        let results = await withTaskGroup(of: (String, [DiscoveryVideo]?).self) { group in
            for creator in DiscoverCreator.all {
                group.addTask {
                    do {
                        let url = URL(string: "https://www.youtube.com/feeds/videos.xml?channel_id=" + creator.id)!
                        let (data, response) = try await session.data(from: url)
                        guard (response as? HTTPURLResponse)?.statusCode == 200 else { return (creator.id, nil) }
                        let items = try VideoFeedParser.parse(data, creator: creator, fetched: now)
                        return (creator.id, items.isEmpty ? nil : items)
                    } catch { return (creator.id, nil) }
                }
            }
            var values: [(String, [DiscoveryVideo]?)] = []
            for await value in group { values.append(value) }
            return values
        }
        guard !Task.isCancelled else { return }
        var failed = 0
        for (id, items) in results {
            if let items { videos.removeAll { $0.creatorID == id }; videos += items }
            else { failed += 1 }
        }
        message = failed == 0 ? "Updated from YouTube’s public channel feeds" : "\(failed) channel feed(s) unavailable. Saved results, if any, remain visible with their original check time."
        if let data = try? JSONEncoder().encode(videos) { UserDefaults.standard.set(data, forKey: "discoveryCache") }
    }
}

struct DiscoverView: View {
    @StateObject private var model = DiscoverModel()
    @State private var category = "All"
    @State private var copied: String?
    let busy: Bool
    let useVideo: (String) -> Void
    private var ranked: [DiscoveryVideo] {
        model.videos.filter { category == "All" || $0.creator == category }.sorted {
            let a = DiscoverySignals.score($0, among: model.videos), b = DiscoverySignals.score($1, among: model.videos)
            return a == b ? $0.published > $1.published : a > b
        }
    }
    var body: some View {
        VStack(alignment: .leading, spacing: 22) {
            HStack {
                VStack(alignment: .leading, spacing: 5) {
                    Text("Discover").font(.system(size: 32, weight: .bold))
                    Text("Find your next story").foregroundStyle(.secondary)
                }
                Spacer()
                Button { Task { await model.refresh() } } label: { Image(systemName: "arrow.clockwise").padding(12).glass(25) }
                    .disabled(model.loading).accessibilityLabel("Refresh recommendations")
            }
            Text("Recent uploads from 3 selected channels, ranked by relative viewing pace, freshness and title signals. Discovery scores are not probabilities of going viral.")
                .font(.caption).foregroundStyle(.secondary)
            ScrollView(.horizontal, showsIndicators: false) {
                HStack {
                    ForEach(["All"] + DiscoverCreator.all.map(\.name), id: \.self) { name in
                        Button { category = name } label: {
                            Text(name).font(.caption.weight(.semibold)).padding(10)
                                .background(category == name ? Color.mint.opacity(0.25) : Color.white.opacity(0.07), in: Capsule())
                        }.buttonStyle(XclipPressStyle())
                    }
                }
            }
            if model.loading { HStack { ProgressView(); Text("Checking recent uploads…").font(.caption) } }
            if !model.message.isEmpty { Text(model.message).font(.caption).foregroundStyle(.secondary) }
            if ranked.isEmpty && !model.loading {
                Text("No feed results yet. Refresh to try again, or explore these channels on YouTube.").foregroundStyle(.secondary)
                ForEach(DiscoverCreator.all) { creator in
                    Link(creator.name + " ↗", destination: URL(string: "https://www.youtube.com/channel/" + creator.id)!)
                }
            }
            ForEach(ranked.prefix(24)) { video in
                VStack(alignment: .leading, spacing: 14) {
                    AsyncImage(url: video.thumbnail, content: { image in image.resizable().scaledToFit() },
                        placeholder: { Rectangle().fill(.white.opacity(0.05)).aspectRatio(16.0 / 9, contentMode: .fit).overlay(Image(systemName: "play.rectangle")) })
                        .clipShape(RoundedRectangle(cornerRadius: 14))
                    HStack(alignment: .top) {
                        VStack(alignment: .leading, spacing: 5) {
                            Text(video.creator).font(.caption).foregroundStyle(.mint)
                            Text(video.title).font(.headline)
                        }
                        Spacer()
                        VStack { Text("\(DiscoverySignals.score(video, among: model.videos))").font(.title.bold()); Text("Discovery").font(.system(size: 9)) }.foregroundStyle(.mint)
                    }
                    if let views = video.views { Text("\(views.formatted()) views · published \(video.published.formatted(date: .abbreviated, time: .omitted))").font(.caption).foregroundStyle(.secondary) }
                    if let pace = DiscoverySignals.relativePace(video, among: model.videos) {
                        Text(String(format: "%.1f× the channel’s recent median viewing pace", pace)).font(.caption.weight(.semibold))
                    } else { Text("Not enough comparable view data for a pace estimate").font(.caption).foregroundStyle(.secondary) }
                    Text(DiscoverySignals.angle(video)).font(.subheadline).foregroundStyle(.secondary)
                    Text(DiscoverySignals.tags(video)).font(.caption).foregroundStyle(.mint)
                    HStack {
                        Button(copied == video.id ? "Copied ✓" : "Copy hashtags") {
                            UIPasteboard.general.string = DiscoverySignals.tags(video); copied = video.id
                        }.font(.caption).padding(10).glass(20)
                        Spacer()
                        Link("Watch ↗", destination: video.url).font(.caption)
                        Button("Use video") { useVideo(video.url.absoluteString) }.font(.caption.bold()).padding(10).glass(20).disabled(busy)
                    }
                    Text("Checked \(video.fetched.formatted(date: .abbreviated, time: .shortened)). Viewing pace is lifetime views ÷ age, not a live growth measurement. Hashtags are topic ideas, not verified trending tags.")
                        .font(.caption2).foregroundStyle(.secondary)
                }.padding(16).glass(24)
            }
            Text("Use videos you own or have permission to edit and repost. Review each source and preserve its context.").font(.caption).foregroundStyle(.secondary)
        }.task {
            if model.videos.isEmpty || Date().timeIntervalSince(model.videos.map(\.fetched).min() ?? .distantPast) > 1800 {
                await model.refresh()
            }
        }
    }
}
