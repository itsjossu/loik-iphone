import AVFoundation

enum AudioAnalyzer {
    /// Half-second RMS bins. The reader streams audio instead of loading the whole video.
    static func energy(url: URL, duration: Double) async throws -> [Double] {
        let asset = AVURLAsset(url: url)
        let tracks = try await asset.loadTracks(withMediaType: .audio)
        guard let track = tracks.first else { return [] }
        let reader = try AVAssetReader(asset: asset)
        let settings: [String: Any] = [AVFormatIDKey: kAudioFormatLinearPCM,
            AVSampleRateKey: 16000, AVNumberOfChannelsKey: 1, AVLinearPCMBitDepthKey: 32,
            AVLinearPCMIsFloatKey: true, AVLinearPCMIsBigEndianKey: false,
            AVLinearPCMIsNonInterleaved: false]
        let output = AVAssetReaderTrackOutput(track: track, outputSettings: settings)
        output.alwaysCopiesSampleData = false
        guard reader.canAdd(output) else { throw LoikError.message("This audio format cannot be analyzed.") }
        reader.add(output)
        guard reader.startReading() else { throw reader.error ?? LoikError.message("Audio analysis could not start.") }
        defer { reader.cancelReading() }
        var sums = Array(repeating: 0.0, count: max(1, Int(ceil(duration * 2))))
        var counts = Array(repeating: 0, count: sums.count)
        while let sample = output.copyNextSampleBuffer() {
            try Task.checkCancellation()
            guard let block = CMSampleBufferGetDataBuffer(sample) else { continue }
            let bytes = CMBlockBufferGetDataLength(block)
            var values = Array(repeating: Float(0), count: bytes / MemoryLayout<Float>.size)
            let copied = values.withUnsafeMutableBytes { buffer in
                CMBlockBufferCopyDataBytes(block, atOffset: 0, dataLength: bytes, destination: buffer.baseAddress!)
            }
            guard copied == kCMBlockBufferNoErr else { continue }
            let offset = CMSampleBufferGetPresentationTimeStamp(sample).seconds
            guard offset.isFinite else { continue }
            for (index, value) in values.enumerated() {
                let bin = Int((offset + Double(index) / 16000) * 2)
                if sums.indices.contains(bin), value.isFinite {
                    sums[bin] += Double(value * value); counts[bin] += 1
                }
            }
        }
        if reader.status == .failed { throw reader.error ?? LoikError.message("Audio analysis failed.") }
        return sums.indices.map { sqrt(sums[$0] / Double(max(1, counts[$0]))) }
    }
}
