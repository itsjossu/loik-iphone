import Foundation
import AVFoundation
import UIKit

enum ProjectStore {
    static var root: URL {
        FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("LoikProjects", isDirectory: true)
    }
    static func directory(_ id: UUID) -> URL { root.appendingPathComponent(id.uuidString, isDirectory: true) }
    static func url(_ project: VideoProject, _ filename: String) -> URL { directory(project.id).appendingPathComponent(filename) }

    static func load() throws -> [VideoProject] {
        try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
        let folders = try FileManager.default.contentsOfDirectory(at: root, includingPropertiesForKeys: nil)
        return folders.compactMap {
            guard let data = try? Data(contentsOf: $0.appendingPathComponent("project.json")) else { return nil }
            return try? JSONDecoder().decode(VideoProject.self, from: data)
        }.sorted { $0.created > $1.created }
    }

    static func save(_ project: VideoProject) throws {
        let folder = directory(project.id)
        try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        var values = URLResourceValues(); values.isExcludedFromBackup = true
        var excluded = folder; try excluded.setResourceValues(values)
        try JSONEncoder().encode(project).write(to: folder.appendingPathComponent("project.json"), options: .atomic)
    }

    static func create(from source: URL, title: String) async throws -> VideoProject {
        let asset = AVURLAsset(url: source)
        let duration = try await asset.load(.duration).seconds
        let tracks = try await asset.loadTracks(withMediaType: .video)
        guard duration.isFinite, duration >= 0.5, !tracks.isEmpty else {
            throw LoikError.message("Choose a video that is at least half a second long.")
        }
        // Avoid pathological files that could exhaust memory during analysis.
        guard duration <= 6 * 3600 else { throw LoikError.message("Please use a video under six hours long.") }
        let suffix = source.pathExtension.isEmpty ? "mov" : source.pathExtension
        let project = VideoProject(title: title, duration: duration, sourceFile: "source." + suffix)
        let folder = directory(project.id)
        try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        do {
            try FileManager.default.copyItem(at: source, to: url(project, project.sourceFile))
            try await thumbnail(video: url(project, project.sourceFile), at: min(1, duration / 2),
                                destination: url(project, project.cover))
            try save(project)
            return project
        } catch { try? FileManager.default.removeItem(at: folder); throw error }
    }

    static func thumbnail(video: URL, at seconds: Double, destination: URL) async throws {
        let generator = AVAssetImageGenerator(asset: AVURLAsset(url: video))
        generator.appliesPreferredTrackTransform = true
        generator.maximumSize = CGSize(width: 600, height: 900)
        let image = try await generator.image(at: CMTime(seconds: max(0, seconds), preferredTimescale: 600)).image
        guard let data = UIImage(cgImage: image).jpegData(compressionQuality: 0.8) else {
            throw LoikError.message("Could not create the video thumbnail.")
        }
        try data.write(to: destination, options: .atomic)
    }
}
