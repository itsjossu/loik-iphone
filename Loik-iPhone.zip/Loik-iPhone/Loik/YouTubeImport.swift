import Foundation
import AVFoundation
import YouTubeKit

enum YouTubeImport {
    static func videoID(_ text: String) -> String? {
        guard let url = URL(string: text.trimmingCharacters(in: .whitespacesAndNewlines)),
              url.scheme == "https" || url.scheme == "http", let host = url.host?.lowercased() else { return nil }
        let parts = url.pathComponents.filter { $0 != "/" }
        let value: String?
        if host == "youtu.be" { value = parts.first }
        else if ["youtube.com", "www.youtube.com", "m.youtube.com", "music.youtube.com"].contains(host) {
            if parts.first == "watch" { value = URLComponents(url: url, resolvingAgainstBaseURL: false)?.queryItems?.first { $0.name == "v" }?.value }
            else if let first = parts.first, ["shorts", "embed", "live"].contains(first), parts.count > 1 { value = parts[1] }
            else { value = nil }
        } else { value = nil }
        guard let value, value.count == 11, value.allSatisfy({ $0.isASCII && ($0.isLetter || $0.isNumber || $0 == "_" || $0 == "-") }) else { return nil }
        return value
    }

    static func fetch(_ text: String, status: @escaping @Sendable (String) async -> Void) async throws -> (URL, String) {
        guard let id = videoID(text) else { throw LoikError.message("Paste a valid YouTube video or Shorts link.") }
        let video = YouTube(videoID: id, methods: [.local])
        await status("Finding video on YouTube…")
        let streams = try await video.streams
        try Task.checkCancellation()
        let title = (try? await video.metadata)?.title ?? "YouTube video"
        let playable = streams.filter { $0.isNativelyPlayable }
        if let combined = playable.filterVideoAndAudio().filter({ $0.fileExtension == .mp4 }).highestResolutionStream() {
            await status("Downloading video and audio…")
            return (try await download(combined), title)
        }
        guard let picture = playable.filterVideoOnly().filter({ $0.fileExtension == .mp4 }).highestResolutionStream(),
              let sound = playable.filterAudioOnly().filter({ $0.fileExtension == .m4a }).highestAudioBitrateStream() else {
            throw LoikError.message("YouTube did not provide a downloadable MP4 with audio. This video may be restricted or unsupported. Try another public video or import its original file.")
        }
        await status("Downloading video…")
        let pictureURL = try await download(picture)
        defer { try? FileManager.default.removeItem(at: pictureURL) }
        await status("Downloading audio…")
        let soundURL = try await download(sound)
        defer { try? FileManager.default.removeItem(at: soundURL) }
        await status("Combining video and audio…")
        let composition = AVMutableComposition()
        let pictureAsset = AVURLAsset(url: pictureURL), soundAsset = AVURLAsset(url: soundURL)
        guard let sourceVideo = try await pictureAsset.loadTracks(withMediaType: .video).first,
              let sourceAudio = try await soundAsset.loadTracks(withMediaType: .audio).first,
              let targetVideo = composition.addMutableTrack(withMediaType: .video, preferredTrackID: kCMPersistentTrackID_Invalid),
              let targetAudio = composition.addMutableTrack(withMediaType: .audio, preferredTrackID: kCMPersistentTrackID_Invalid) else {
            throw LoikError.message("The downloaded video and audio could not be combined.")
        }
        let videoDuration = try await pictureAsset.load(.duration)
        let audioDuration = try await soundAsset.load(.duration)
        let range = CMTimeRange(start: .zero, duration: CMTimeMinimum(videoDuration, audioDuration))
        try targetVideo.insertTimeRange(range, of: sourceVideo, at: .zero)
        try targetAudio.insertTimeRange(range, of: sourceAudio, at: .zero)
        targetVideo.preferredTransform = try await sourceVideo.load(.preferredTransform)
        guard let export = AVAssetExportSession(asset: composition, presetName: AVAssetExportPresetPassthrough) else {
            throw LoikError.message("The downloaded video could not be prepared.")
        }
        let output = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString + ".mp4")
        export.outputURL = output; export.outputFileType = .mp4
        do { try await VideoEngine.performExport(export); return (output, title) }
        catch { try? FileManager.default.removeItem(at: output); throw error }
    }

    private static func download(_ stream: YouTubeKit.Stream) async throws -> URL {
        try await stream.waitUntilAvailable()
        let configuration = URLSessionConfiguration.ephemeral
        configuration.timeoutIntervalForRequest = 60
        configuration.timeoutIntervalForResource = 1800
        let session = URLSession(configuration: configuration)
        defer { session.invalidateAndCancel() }
        var request = URLRequest(url: stream.url)
        request.setValue("Mozilla/5.0", forHTTPHeaderField: "User-Agent")
        let (temporary, response) = try await session.download(for: request)
        defer { try? FileManager.default.removeItem(at: temporary) }
        try Task.checkCancellation()
        guard let response = response as? HTTPURLResponse, (200..<300).contains(response.statusCode) else {
            throw LoikError.message("YouTube refused the video download. Try another public video or import the original file.")
        }
        let output = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString + "." + (stream.fileExtension == .m4a ? "m4a" : "mp4"))
        try FileManager.default.moveItem(at: temporary, to: output)
        return output
    }
}
