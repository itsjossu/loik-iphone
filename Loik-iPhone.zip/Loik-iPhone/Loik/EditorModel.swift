import SwiftUI
import AVFoundation
import PhotosUI
import Photos

@MainActor
final class EditorModel: ObservableObject {
    @Published var projects: [VideoProject] = []
    @Published var selectedID: UUID?
    @Published var settings = ClipSettings()
    @Published var showSettings = false
    @Published var busy = false
    @Published var canStop = false
    @Published var status = ""
    @Published var progress = 0.0
    @Published var error: String?
    @Published var shareURLs: [URL] = []
    @Published var showShare = false
    private let speech = SpeechService()
    private var processing: Task<Void, Never>?

    var project: VideoProject? { projects.first { $0.id == selectedID } }

    init() {
        do { projects = try ProjectStore.load() }
        catch { self.error = "Your project library could not be loaded: \(error.localizedDescription)" }
        if let data = UserDefaults.standard.data(forKey: "clipDefaults"),
           let saved = try? JSONDecoder().decode(ClipSettings.self, from: data) { settings = saved }
        if ProcessInfo.processInfo.arguments.contains("--preview-gallery") || ProcessInfo.processInfo.arguments.contains("--preview-settings") {
            let clips = (0..<4).map { index in
                GeneratedClip(title: ["Why the first few seconds matter", "The moment everything changed", "A different way to tell the story", "Here is what happened next"][index],
                    start: Double(index * 35), end: Double(index * 35 + 30), score: [91, 86, 81, 76][index],
                    reasons: ["Preview data"], analysis: "Preview data only", file: "sample.mp4", thumbnail: "sample.jpg",
                    captions: [], aspect: .portrait)
            }
            let sample = VideoProject(title: "A story worth sharing", duration: 240, sourceFile: "sample.mov", clips: clips,
                                      note: "Preview data · visual layout only")
            projects = [sample]; selectedID = sample.id
            showSettings = ProcessInfo.processInfo.arguments.contains("--preview-settings")
        }
    }

    func saveDefaults() {
        if let data = try? JSONEncoder().encode(settings) { UserDefaults.standard.set(data, forKey: "clipDefaults") }
        status = "Default settings saved"
    }

    func select(_ project: VideoProject) { selectedID = project.id; settings = project.settings }

    private func store(_ project: VideoProject) throws {
        try ProjectStore.save(project)
        if let index = projects.firstIndex(where: { $0.id == project.id }) { projects[index] = project }
        else { projects.insert(project, at: 0) }
    }

    func importPhoto(_ item: PhotosPickerItem) async {
        guard !busy else { return }
        busy = true; progress = 0; status = "Importing video…"
        defer { busy = false }
        do {
            guard let movie = try await item.loadTransferable(type: ImportedMovie.self) else {
                throw LoikError.message("This video could not be imported.")
            }
            defer { try? FileManager.default.removeItem(at: movie.url) }
            var project = try await ProjectStore.create(from: movie.url, title: "Untitled project")
            project.settings = settings
            try store(project); selectedID = project.id; showSettings = true
        } catch { self.error = error.localizedDescription }
    }

    func importFile(_ url: URL) async {
        guard !busy else { return }
        busy = true; progress = 0; status = "Importing video…"
        defer { busy = false }
        let access = url.startAccessingSecurityScopedResource()
        defer { if access { url.stopAccessingSecurityScopedResource() } }
        do {
            var project = try await ProjectStore.create(from: url, title: url.deletingPathExtension().lastPathComponent)
            project.settings = settings
            try store(project); selectedID = project.id; showSettings = true
        } catch { self.error = error.localizedDescription }
    }

    func generate() {
        guard let project, !busy else { return }
        showSettings = false
        busy = true; canStop = true; progress = 0; status = "Reading audio activity…"
        let chosenSettings = settings
        processing = Task { await run(project, settings: chosenSettings) }
    }

    func cancel() { processing?.cancel(); speech.cancel() }

    func importYouTube(_ link: String) {
        guard !busy else { return }
        busy = true; canStop = true; progress = 0
        processing = Task {
            defer { busy = false; canStop = false; processing = nil }
            do {
                let (url, title) = try await YouTubeImport.fetch(link) { [weak self] message in
                    await MainActor.run { self?.status = message }
                }
                defer { try? FileManager.default.removeItem(at: url) }
                try Task.checkCancellation()
                status = "Saving imported video…"
                var project = try await ProjectStore.create(from: url, title: title)
                project.settings = settings
                try store(project); selectedID = project.id; showSettings = true
                status = "Video ready to clip"
            } catch is CancellationError { status = "YouTube import cancelled" }
            catch { self.error = "YouTube import failed: \(error.localizedDescription)"; status = "Import stopped" }
        }
    }

    private func run(_ original: VideoProject, settings: ClipSettings) async {
        var project = original
        project.settings = settings
        defer { busy = false; canStop = false; processing = nil }
        let source = ProjectStore.url(project, project.sourceFile)
        var transcript: [Caption] = []
        var notes: [String] = []
        do {
            try Task.checkCancellation()
            let energyURL = ProjectStore.url(project, "audio-analysis-v1.json")
            let energy: [Double]
            if let data = try? Data(contentsOf: energyURL),
               let saved = try? JSONDecoder().decode([Double].self, from: data) {
                energy = saved
                status = "Reusing saved audio analysis…"
            } else {
                energy = try await AudioAnalyzer.energy(url: source, duration: project.duration)
                try Task.checkCancellation()
                if let data = try? JSONEncoder().encode(energy) { try? data.write(to: energyURL, options: .atomic) }
            }
            let localeKey = Data(settings.locale.utf8).map { String(format: "%02x", Int($0)) }.joined()
            let speechURL = ProjectStore.url(project, "speech-analysis-v1-" + localeKey + ".json")
            progress = 0.08
            var useSpeech = settings.useSpeech || settings.subtitles
            if useSpeech, let data = try? Data(contentsOf: speechURL),
               let saved = try? JSONDecoder().decode([Caption].self, from: data), !saved.isEmpty {
                transcript = saved
                status = "Reusing saved transcript…"
                useSpeech = false
            }
            if useSpeech {
                do { try await speech.prepare(locale: settings.locale) }
                catch { notes.append(error.localizedDescription); useSpeech = false }
            }
            if useSpeech && !energy.isEmpty {
                let windows = Int(ceil(project.duration / 50))
                var failed = 0
                for index in 0..<windows {
                    try Task.checkCancellation()
                    let start = Double(index) * 50, end = min(project.duration, start + 50)
                    status = "Understanding speech · section \(index + 1) of \(windows)…"
                    let audio = try await VideoEngine.audio(url: source, start: start, end: end)
                    defer { try? FileManager.default.removeItem(at: audio) }
                    do {
                        let cues = try await speech.recognize(url: audio, locale: settings.locale)
                        transcript += cues.map { Caption(start: $0.start + start, duration: $0.duration, text: $0.text) }
                    } catch is CancellationError { throw CancellationError() }
                    catch { failed += 1 }
                    progress = 0.08 + 0.42 * Double(index + 1) / Double(windows)
                }
                try Task.checkCancellation()
                if failed == 0, !transcript.isEmpty, let data = try? JSONEncoder().encode(transcript) {
                    try? data.write(to: speechURL, options: .atomic)
                }
                if failed > 0 { notes.append("Speech could not be read in \(failed) section(s); audio activity was used there.") }
            }
            if settings.partLength == nil && energy.isEmpty && transcript.isEmpty {
                throw LoikError.message("No audio track was found. Smart highlights need audio or speech to compare moments.")
            }
            try Task.checkCancellation()
            status = settings.partLength == nil ? "Ranking the strongest moments…" : "Finding natural breaks…"; progress = 0.52
            let duration = project.duration
            let allCaptions = transcript
            let moments = await Task.detached(priority: .userInitiated) {
                if let length = settings.partLength {
                    return HighlightScorer.parts(duration: duration, length: length, count: settings.count,
                                                 energy: energy, captions: allCaptions)
                }
                return HighlightScorer.rank(duration: duration, length: settings.length, count: settings.count,
                                     energy: energy, captions: allCaptions)
            }.value
            guard !moments.isEmpty else { throw LoikError.message("No suitable moments were found. Try a shorter clip length.") }
            if moments.count < settings.count { notes.append("This source has room for \(moments.count) distinct clip(s) at this length.") }
            if transcript.isEmpty && settings.partLength == nil { notes.append("Audio-only ranking. Automatic captions and speech-based titles are unavailable.") }
            project.note = notes.isEmpty ? (settings.partLength == nil ? "Ranked using speech, pacing and audio activity" : "Sequential parts") : notes.joined(separator: " ")
            try store(project)
            for (index, moment) in moments.enumerated() {
                try Task.checkCancellation()
                status = "Creating clip \(index + 1) of \(moments.count)… Keep the app open."
                let cues = settings.subtitles ? HighlightScorer.relativeCaptions(transcript, start: moment.start, end: moment.end) : []
                let title = settings.partLength != nil || moment.usesSpeech ? moment.title : "\(project.title) · \(ClipLogic.timestamp(moment.start))"
                let headline = settings.headline && (settings.partLength != nil || moment.usesSpeech) ? title : nil
                var renderInputs: [String] = [
                    "v2", settings.partLength == nil ? "" : title, String(moment.start), String(moment.end), settings.aspect.rawValue,
                    settings.style.rawValue, headline ?? ""
                ]
                for cue in cues {
                    renderInputs.append(contentsOf: [String(cue.start), String(cue.duration), cue.text])
                }
                let renderKey = try JSONEncoder().encode(renderInputs).base64EncodedString()
                if project.clips.contains(where: { clip in
                    clip.renderKey == renderKey &&
                    FileManager.default.fileExists(atPath: ProjectStore.url(project, clip.file).path)
                }) {
                    progress = 0.55 + 0.45 * Double(index + 1) / Double(moments.count)
                    continue
                }
                let output = try await VideoEngine.export(url: source, start: moment.start, end: moment.end,
                    vertical: settings.aspect == .portrait, captions: cues, aspect: settings.aspect.ratio,
                    headline: headline, style: settings.style)
                defer { try? FileManager.default.removeItem(at: output) }
                try Task.checkCancellation()
                let id = UUID(), file = id.uuidString + ".mp4", thumbnail = id.uuidString + ".jpg"
                let destination = ProjectStore.url(project, file)
                try FileManager.default.moveItem(at: output, to: destination)
                do {
                    try await ProjectStore.thumbnail(video: destination, at: min(0.5, (moment.end - moment.start) / 2),
                                                     destination: ProjectStore.url(project, thumbnail))
                    project.clips.append(GeneratedClip(id: id, title: title, start: moment.start, end: moment.end,
                        score: moment.score, reasons: moment.reasons,
                        analysis: settings.partLength != nil ? "Sequential part" : moment.usesSpeech ? "Speech + audio" : "Audio only", file: file, thumbnail: thumbnail,
                        captions: cues, aspect: settings.aspect, renderKey: renderKey))
                    project.clips.sort { $0.score == $1.score ? $0.start < $1.start : $0.score > $1.score }
                    try store(project)
                } catch { try? FileManager.default.removeItem(at: destination); throw error }
                progress = 0.55 + 0.45 * Double(index + 1) / Double(moments.count)
            }
            status = "\(moments.count) clips ready"; progress = 1
        } catch is CancellationError { status = "Stopped. Completed clips are saved." }
        catch { self.error = error.localizedDescription; status = "Stopped. Completed clips are saved." }
    }

    func rename(_ project: VideoProject, title: String) {
        let clean = title.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !clean.isEmpty else { return }
        var updated = project; updated.title = String(clean.prefix(150))
        do { try store(updated) } catch { self.error = error.localizedDescription }
    }

    func remove(_ project: VideoProject) {
        guard !busy else { return }
        do {
            try FileManager.default.removeItem(at: ProjectStore.directory(project.id))
            projects.removeAll { $0.id == project.id }
            if selectedID == project.id { selectedID = nil }
        } catch { self.error = error.localizedDescription }
    }

    func share(_ clips: [GeneratedClip], project: VideoProject) {
        shareURLs = clips.map { ProjectStore.url(project, $0.file) }
        showShare = !shareURLs.isEmpty
    }

    func save(_ clips: [GeneratedClip], project: VideoProject) async {
        guard !busy, !clips.isEmpty else { return }
        busy = true; status = "Saving to Photos…"
        defer { busy = false }
        let permission = await PHPhotoLibrary.requestAuthorization(for: .addOnly)
        guard permission == .authorized || permission == .limited else {
            error = "Allow saving to Photos in Settings, or use Share to save to Files."
            return
        }
        let urls = clips.map { ProjectStore.url(project, $0.file) }
        do {
            try await PHPhotoLibrary.shared().performChanges {
                for url in urls { PHAssetChangeRequest.creationRequestForAssetFromVideo(atFileURL: url) }
            }
            status = "\(clips.count) clip(s) saved to Photos"
        } catch { self.error = error.localizedDescription }
    }
}

