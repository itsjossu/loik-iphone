import SwiftUI
import AVFoundation
import PhotosUI
import Photos

@MainActor
final class EditorModel: ObservableObject {
    @Published var source: URL?
    @Published var player: AVPlayer?
    @Published var duration = 0.0
    @Published var start = 0.0
    @Published var end = 0.0
    @Published var vertical = true
    @Published var captions: [Caption] = []
    @Published var currentTime = 0.0
    @Published var busy = false
    @Published var status = ""
    @Published var error: String?
    @Published var exported: URL?
    @Published var share = false
    @Published var locale = "en-US"
    @Published var originalAspect = 16.0 / 9.0
    private var observer: Any?
    private let speech = SpeechService()

    var length: Double { max(0, end - start) }
    var activeCaption: String {
        let relative = currentTime - start
        return captions.first { relative >= $0.start && relative < $0.start + $0.duration }?.text ?? ""
    }

    func importPhoto(_ item: PhotosPickerItem) async {
        guard !busy else { return }
        busy = true; status = "Video laadimine…"
        defer { busy = false }
        do {
            guard let movie = try await item.loadTransferable(type: ImportedMovie.self) else {
                throw LoikError.message("Videot ei õnnestunud avada.")
            }
            try await load(movie.url)
        } catch { self.error = error.localizedDescription }
    }

    func importFile(_ url: URL) async {
        guard !busy else { return }
        busy = true; status = "Video laadimine…"
        defer { busy = false }
        do {
            let target = try await Task.detached(priority: .userInitiated) {
                let access = url.startAccessingSecurityScopedResource()
                defer { if access { url.stopAccessingSecurityScopedResource() } }
                let target = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
                    .appendingPathExtension(url.pathExtension)
                try FileManager.default.copyItem(at: url, to: target)
                return target
            }.value
            try await load(target)
        } catch { self.error = error.localizedDescription }
    }

    private func load(_ url: URL) async throws {
        do {
            let asset = AVURLAsset(url: url)
            let seconds = try await asset.load(.duration).seconds
            guard seconds.isFinite, seconds >= 0.5,
                  let track = try await asset.loadTracks(withMediaType: .video).first else {
                throw LoikError.message("Vali vähemalt poole sekundi pikkune video.")
            }
            let naturalSize = try await track.load(.naturalSize)
            let transform = try await track.load(.preferredTransform)
            let rect = CGRect(origin: .zero, size: naturalSize).applying(transform)
            if let observer, let player { player.removeTimeObserver(observer) }
            observer = nil
            player?.pause()
            player?.replaceCurrentItem(with: nil)
            if let source { try? FileManager.default.removeItem(at: source) }
            clearExport()
            source = url; duration = seconds; start = 0; end = min(30, seconds)
            originalAspect = Double(rect.width / max(1, rect.height))
            captions = []; currentTime = 0
            let next = AVPlayer(url: url)
            player = next
            observer = next.addPeriodicTimeObserver(forInterval: CMTime(seconds: 0.1, preferredTimescale: 600),
                                                     queue: .main) { [weak self] time in
                Task { @MainActor in
                    guard let self else { return }
                    self.currentTime = time.seconds
                    if time.seconds >= self.end { self.player?.pause() }
                }
            }
            status = "Video valmis. Vali sobiv lõik."
        } catch { try? FileManager.default.removeItem(at: url); throw error }
    }

    private func clearExport() {
        if let exported { try? FileManager.default.removeItem(at: exported) }
        exported = nil
    }

    func rangeChanged() {
        player?.pause()
        captions = []
        clearExport()
        player?.seek(to: CMTime(seconds: start, preferredTimescale: 600), toleranceBefore: .zero, toleranceAfter: .zero)
        currentTime = start
    }

    func choose(_ clip: ClipRange) { start = clip.start; end = clip.end; rangeChanged() }

    func play() {
        guard let player else { return }
        if player.rate > 0 { player.pause(); return }
        if currentTime < start || currentTime >= end - 0.1 {
            player.seek(to: CMTime(seconds: start, preferredTimescale: 600), toleranceBefore: .zero,
                        toleranceAfter: .zero) { done in
                if done { Task { @MainActor [weak self] in self?.player?.play() } }
            }
        } else { player.play() }
    }

    func transcribe() async {
        guard let source, !busy else { return }
        guard length <= 55 else {
            error = "Kohaliku kõnetuvastuse jaoks vali kuni 55-sekundiline lõik."
            return
        }
        busy = true; status = "Kõne tuvastamine telefonis…"; player?.pause()
        defer { busy = false }
        do {
            let audio = try await VideoEngine.audio(url: source, start: start, end: end)
            defer { try? FileManager.default.removeItem(at: audio) }
            let result = try await speech.recognize(url: audio, locale: locale)
            captions = result
            clearExport()
            status = "Subtiitrid valmis. Kontrolli teksti enne eksportimist."
        } catch { self.error = error.localizedDescription; status = "Kõnetuvastus ei õnnestunud." }
    }

    func manual(_ text: String) {
        captions = ClipLogic.manualCaptions(text: text, duration: length)
        clearExport()
        status = "Tekst on jaotatud klipi peale ühtlaselt; ajastus ei põhine kõnel."
    }

    func export() async {
        guard let source, !busy else { return }
        busy = true; status = "MP4 loomine… Hoia rakendus avatuna."; player?.pause()
        defer { busy = false }
        do {
            let output = try await VideoEngine.export(url: source, start: start, end: end,
                                                      vertical: vertical, captions: captions)
            clearExport(); exported = output
            status = "MP4 valmis. Salvesta Fotodesse või jaga."
        } catch { self.error = error.localizedDescription; status = "Eksport ei õnnestunud." }
    }

    func saveToPhotos() async {
        guard let exported, !busy else { return }
        busy = true; status = "Salvestamine…"
        defer { busy = false }
        let permission = await PHPhotoLibrary.requestAuthorization(for: .addOnly)
        guard permission == .authorized || permission == .limited else {
            error = "Luba Fotodesse lisamine seadetes või kasuta jagamisnuppu."
            return
        }
        do {
            try await PHPhotoLibrary.shared().performChanges {
                PHAssetChangeRequest.creationRequestForAssetFromVideo(atFileURL: exported)
            }
            status = "Klipp salvestatud Fotodesse."
        } catch { self.error = error.localizedDescription }
    }
}
