import SwiftUI

@main
struct LoikApp: App {
    var body: some Scene {
        WindowGroup { XclipRootView().preferredColorScheme(.dark).environment(\.locale, Locale(identifier: "en")) }
    }
}

struct XclipRootView: View {
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var ready = false
    @State private var revealed = false

    var body: some View {
        ZStack {
            EditorView().allowsHitTesting(ready).accessibilityHidden(!ready)
            if !ready {
                ZStack {
                    Color(red: 0.035, green: 0.05, blue: 0.075).ignoresSafeArea()
                    VStack(spacing: 20) {
                        ZStack {
                            RoundedRectangle(cornerRadius: 26)
                                .fill(.mint.opacity(0.08))
                                .overlay(RoundedRectangle(cornerRadius: 26).stroke(.mint.opacity(0.25)))
                            Image(systemName: "xmark")
                                .font(.system(size: 43, weight: .black, design: .rounded))
                                .foregroundStyle(.mint)
                                .scaleEffect(revealed || reduceMotion ? 1 : 0.76)
                        }
                        .frame(width: 96, height: 96)
                        .shadow(color: .mint.opacity(revealed ? 0.24 : 0), radius: 24)
                        Text("Xclip")
                            .font(.system(size: 36, weight: .bold, design: .rounded))
                            .tracking(1)
                            .opacity(revealed || reduceMotion ? 1 : 0)
                            .offset(y: revealed || reduceMotion ? 0 : 8)
                        Capsule()
                            .fill(.white.opacity(0.09))
                            .overlay(alignment: .leading) {
                                Capsule().fill(LinearGradient(colors: [.teal, .mint], startPoint: .leading, endPoint: .trailing))
                                    .frame(width: revealed || reduceMotion ? 112 : 12)
                            }
                            .frame(width: 112, height: 3)
                            .accessibilityHidden(true)
                    }
                    .accessibilityElement(children: .ignore)
                    .accessibilityLabel("Opening Xclip")
                }
                .transition(.opacity)
                .zIndex(1)
            }
        }
        .task {
            withAnimation(reduceMotion ? nil : .easeOut(duration: 1.55)) { revealed = true }
            if !reduceMotion {
                do { try await Task.sleep(for: .milliseconds(1600)) }
                catch { return }
            }
            withAnimation(reduceMotion ? nil : .easeOut(duration: 0.32)) { ready = true }
        }
    }
}

struct XclipPressStyle: ButtonStyle {
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    func makeBody(configuration: Configuration) -> some View {
        configuration.label.scaleEffect(configuration.isPressed && !reduceMotion ? 0.97 : 1)
            .opacity(configuration.isPressed ? 0.8 : 1)
            .animation(reduceMotion ? nil : .spring(response: 0.28, dampingFraction: 0.7), value: configuration.isPressed)
    }
}
