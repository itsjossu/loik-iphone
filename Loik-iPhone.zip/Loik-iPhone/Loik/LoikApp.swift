import SwiftUI

@main
struct LoikApp: App {
    var body: some Scene {
        WindowGroup { XclipRootView().preferredColorScheme(.dark).environment(\.locale, Locale(identifier: "en")) }
    }
}

struct XclipRootView: View {
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var ready = false
    @State private var spinning = false
    var body: some View {
        ZStack {
            EditorView()
            if !ready {
                ZStack {
                    AuroraBackground()
                    VStack(spacing: 28) {
                        ZStack {
                            Circle().stroke(.white.opacity(0.1), lineWidth: 2)
                            Circle().trim(from: 0, to: 0.68)
                                .stroke(AngularGradient(colors: [.clear, .cyan, .mint], center: .center),
                                        style: StrokeStyle(lineWidth: 3, lineCap: .round))
                                .rotationEffect(.degrees(spinning && !reduceMotion ? 360 : 0))
                            Text("X").font(.system(size: 70, weight: .black, design: .rounded))
                                .foregroundStyle(LinearGradient(colors: [.white, .mint], startPoint: .top, endPoint: .bottom))
                        }.frame(width: 132, height: 132)
                        VStack(spacing: 10) {
                            Text("Xclip").font(.system(size: 38, weight: .bold, design: .rounded))
                            Text("Make every moment count.").font(.subheadline).foregroundStyle(.white.opacity(0.6))
                        }
                        ProgressView().tint(.mint).accessibilityLabel("Opening Xclip")
                    }
                }.transition(.opacity).zIndex(1)
                    .onAppear {
                        withAnimation(reduceMotion ? nil : .linear(duration: 1.2).repeatForever(autoreverses: false)) { spinning = true }
                    }
            }
        }.task {
            try? await Task.sleep(for: .milliseconds(reduceMotion ? 200 : 950))
            withAnimation(reduceMotion ? nil : .easeOut(duration: 0.3)) { ready = true }
        }
    }
}

struct XclipPressStyle: ButtonStyle {
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    func makeBody(configuration: Configuration) -> some View {
        configuration.label.scaleEffect(configuration.isPressed && !reduceMotion ? 0.97 : 1)
            .opacity(configuration.isPressed ? 0.8 : 1)
            .animation(reduceMotion ? nil : .spring(response: 0.28, dampingFraction: 0.7), value: configuration.isPressed)
    }
}
