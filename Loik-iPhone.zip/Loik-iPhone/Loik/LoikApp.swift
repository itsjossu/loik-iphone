import SwiftUI

@main
struct LoikApp: App {
    var body: some Scene {
        WindowGroup { EditorView().preferredColorScheme(.dark) }
    }
}
