import SwiftUI

@main
struct LoikApp: App {
    var body: some Scene {
        WindowGroup { XclipRootView().preferredColorScheme(.dark).environment(\.locale, Locale(identifier: "en")) }
    }
}

struct XclipRootView: View {
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var ready = false
    @State private var spinning = false
    @State private var revealed = false
    var body: some View {
        ZStack {
            EditorView().allowsHitTesting(ready).accessibilityHidden(!ready)
            if !ready {
                ZStack {
                    AuroraBackground()
                    ForEach(0..<9) { index in
                        RoundedRectangle(cornerRadius: 4).fill(index.isMultiple(of: 2) ? Color.mint.opacity(0.3) : Color.cyan.opacity(0.25))
                            .frame(width: 4, height: CGFloat(18 + index * 4))
                            .rotationEffect(.degrees(Double(index) * 40))
                            .offset(x: CGFloat(cos(Double(index) * .pi / 4.5)) * (revealed ? 125 : 40),
                                    y: CGFloat(sin(Double(index) * .pi / 4.5)) * (revealed ? 125 : 40))
                            .opacity(revealed ? 0 : 1)
                    }
                    VStack(spacing: 28) {
                        ZStack {
                            Circle().stroke(.white.opacity(0.1), lineWidth: 2)
                            Circle().trim(from: 0, to: 0.68)
                                .stroke(AngularGradient(colors: [.clear, .cyan, .mint], center: .center),
                                        style: StrokeStyle(lineWidth: 3, lineCap: .round))
                                .rotationEffect(.degrees(spinning && !reduceMotion ? 360 : 0))
                            Text("X").font(.system(size: 70, weight: .black, design: .rounded))
                                .foregroundStyle(LinearGradient(colors: [.white, .mint], startPoint: .top, endPoint: .bottom))
                                .scaleEffect(revealed ? 1 : 0.45)
                                .rotationEffect(.degrees(revealed || reduceMotion ? 0 : -90))
                        }.frame(width: 132, height: 132)
                        VStack(spacing: 10) {
                            Text("Xclip").font(.system(size: 38, weight: .bold, design: .rounded))
                            Text("Make every moment count.").font(.subheadline).foregroundStyle(.white.opacity(0.6))
                        }
                        ProgressView().tint(.mint).accessibilityLabel("Opening Xclip")
                    }
                }.transition(.opacity).zIndex(1)
                    .onAppear {
                        withAnimation(reduceMotion ? nil : .linear(duration: 1.2).repeatForever(autoreverses: false)) { spinning = true }
                        withAnimation(reduceMotion ? nil : .spring(response: 0.75, dampingFraction: 0.58)) { revealed = true }
                    }
            }
        }.task {
            try? await Task.sleep(for: .milliseconds(reduceMotion ? 200 : 1350))
            withAnimation(reduceMotion ? nil : .easeOut(duration: 0.3)) { ready = true }
        }
    }
}

struct XclipPressStyle: ButtonStyle {
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    func makeBody(configuration: Configuration) -> some View {
        configuration.label.scaleEffect(configuration.isPressed && !reduceMotion ? 0.97 : 1)
            .opacity(configuration.isPressed ? 0.8 : 1)
            .animation(reduceMotion ? nil : .spring(response: 0.28, dampingFraction: 0.7), value: configuration.isPressed)
    }
}
