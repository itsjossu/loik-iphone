import Speech
import Foundation

// All recognition is explicitly on-device; no remote fallback or paid API.
@MainActor
final class SpeechService {
    private var task: SFSpeechRecognitionTask?
    private var deadline: Task<Void, Never>?
    private var pending: CheckedContinuation<[Caption], Error>?

    func recognize(url: URL, locale: String) async throws -> [Caption] {
        let permission = await withCheckedContinuation { continuation in
            SFSpeechRecognizer.requestAuthorization { continuation.resume(returning: $0) }
        }
        guard permission == .authorized else {
            throw LoikError.message("Luba kõnetuvastus iPhone’i seadetes või sisesta subtiitrid käsitsi.")
        }
        guard let recognizer = SFSpeechRecognizer(locale: Locale(identifier: locale)),
              recognizer.supportsOnDeviceRecognition, recognizer.isAvailable else {
            throw LoikError.message("Selle keele kohalik kõnetuvastus pole praegu saadaval. Proovi teist keelt või sisesta tekst käsitsi. Eesti keele tuge ei saa lubada.")
        }
        let request = SFSpeechURLRecognitionRequest(url: url)
        request.requiresOnDeviceRecognition = true
        request.shouldReportPartialResults = false
        request.taskHint = .dictation
        return try await withCheckedThrowingContinuation { continuation in
            pending = continuation
            task = recognizer.recognitionTask(with: request) { [weak self] result, error in
                Task { @MainActor in
                    guard let self, self.pending != nil else { return }
                    if let result, result.isFinal {
                        let segments = result.bestTranscription.segments
                        var captions: [Caption] = []
                        var group: [SFTranscriptionSegment] = []
                        for segment in segments {
                            if let previous = group.last,
                               group.count >= 7 || segment.timestamp - (previous.timestamp + previous.duration) > 0.7 {
                                captions.append(Self.caption(group)); group = []
                            }
                            group.append(segment)
                        }
                        if !group.isEmpty { captions.append(Self.caption(group)) }
                        if captions.isEmpty {
                            self.finish(.failure(LoikError.message("Kõnet ei tuvastatud. Lisa tekst käsitsi.")))
                        } else { self.finish(.success(captions)) }
                    } else if let error { self.finish(.failure(error)) }
                }
            }
            deadline = Task { [weak self] in
                do { try await Task.sleep(nanoseconds: 90_000_000_000) }
                catch { return }
                self?.finish(.failure(LoikError.message("Kõnetuvastus võttis liiga kaua aega. Proovi lühemat lõiku.")))
            }
        }
    }

    private static func caption(_ group: [SFTranscriptionSegment]) -> Caption {
        let first = group[0], last = group[group.count - 1]
        return Caption(start: first.timestamp,
                       duration: max(0.1, last.timestamp + last.duration - first.timestamp),
                       text: group.map(\.substring).joined(separator: " "))
    }

    private func finish(_ result: Result<[Caption], Error>) {
        let continuation = pending
        pending = nil
        deadline?.cancel(); deadline = nil
        task?.cancel(); task = nil
        continuation?.resume(with: result)
    }
}
