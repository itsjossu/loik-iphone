import Foundation

enum Aspect: String, Codable, CaseIterable, Identifiable {
    case portrait = "9:16", square = "1:1", landscape = "16:9", social = "4:5"
    var id: String { rawValue }
    var ratio: Double {
        switch self {
        case .portrait: return 9.0 / 16
        case .square: return 1
        case .landscape: return 16.0 / 9
        case .social: return 4.0 / 5
        }
    }
}

enum CaptionStyle: String, Codable, CaseIterable, Identifiable {
    case bold = "Bold", mint = "Mint", clean = "Clean"
    var id: String { rawValue }
}

struct ClipSettings: Codable {
    var count = 4
    var length = 30.0
    var aspect = Aspect.portrait
    var headline = true
    var subtitles = true
    var useSpeech = true
    var locale = "en-US"
    var style = CaptionStyle.bold
}

struct GeneratedClip: Identifiable, Codable {
    var id = UUID()
    var title: String
    var start: Double
    var end: Double
    var score: Int
    var reasons: [String]
    var analysis: String
    var file: String
    var thumbnail: String
    var captions: [Caption]
    var aspect: Aspect
    var duration: Double { end - start }
}

struct VideoProject: Identifiable, Codable {
    var id = UUID()
    var title: String
    var created = Date()
    var duration: Double
    var sourceFile: String
    var cover = "cover.jpg"
    var clips: [GeneratedClip] = []
    var note = "Ready to create clips"
    var settings = ClipSettings()
}

struct RankedMoment {
    var start: Double
    var end: Double
    var score: Int
    var title: String
    var reasons: [String]
    var usesSpeech: Bool
}

enum HighlightScorer {
    static func words(_ text: String) -> [String] {
        text.lowercased().split { !$0.isLetter && !$0.isNumber && $0 != "'" }.map(String.init)
    }

    /// Local editorial heuristic. This is not a trained virality predictor.
    static func rank(duration: Double, length: Double, count: Int,
                     energy: [Double], captions: [Caption]) -> [RankedMoment] {
        guard duration.isFinite, duration > 0, length.isFinite, length > 0, count > 0 else { return [] }
        let target = min(duration, length)
        let step = max(1, target / 4)
        var starts = stride(from: 0.0, through: max(0, duration - target), by: step).map { $0 }
        starts.append(max(0, duration - target))
        starts.append(contentsOf: captions.map { max(0, min(duration - target, $0.start - 0.15)) })
        let sortedEnergy = energy.sorted()
        let median = sortedEnergy.isEmpty ? 0 : sortedEnergy[sortedEnergy.count / 2]
        let peak = energy.max() ?? 0
        let boundaries = captions.map { $0.start + $0.duration }
        var candidates: [RankedMoment] = []
        let hooks: Set<String> = ["why", "how", "never", "secret", "mistake", "imagine", "but", "because",
                                  "best", "worst", "finally", "happened", "watch", "first", "here's", "don't", "unexpected"]
        var seen = Set<Int>()
        for start in starts where seen.insert(Int(start * 2)).inserted {
            let proposedEnd = min(duration, start + target)
            // Prefer a completed utterance close to the requested length.
            let nearby = boundaries.filter { $0 >= start + target * 0.75 && abs($0 - proposedEnd) <= min(6, target * 0.2) && $0 <= duration }
            let end = nearby.min(by: { abs($0 - proposedEnd) < abs($1 - proposedEnd) }) ?? proposedEnd
            let selected = captions.filter { $0.start >= start && $0.start < end }
            let text = selected.map(\.text).joined(separator: " ")
            let tokens = words(text)
            let lower = min(energy.count, max(0, Int(ceil(start * 2))))
            let upper = min(energy.count, max(lower, Int(ceil(end * 2))))
            let bins = Array(energy[lower..<upper])
            let average = bins.reduce(0, +) / Double(max(1, bins.count))
            let active = Double(bins.filter { $0 > max(0.003, peak * 0.06) }.count) / Double(max(1, bins.count))
            let relativeEnergy = peak > 0.0001 ? min(1, average / max(0.004, median * 1.7)) : 0
            let variation = bins.isEmpty ? 0 : min(1, ((bins.max() ?? 0) - (bins.min() ?? 0)) / max(0.01, peak))
            var reasons: [String] = []
            var score: Double
            if !tokens.isEmpty {
                let opening = Array(tokens.prefix(18))
                let startsQuickly = max(0, 1 - ((selected.first?.start ?? start) - start) / 4)
                let hook = min(1, Double(Set(opening).intersection(hooks).count) / 2) * startsQuickly
                let rate = Double(tokens.count) / max(1, end - start)
                let pace = max(0, 1 - abs(rate - 2.3) / 2.3)
                let variety = Double(Set(tokens).count) / Double(tokens.count)
                let speechTime = selected.reduce(0.0) { $0 + max(0, min(end, $1.start + $1.duration) - max(start, $1.start)) }
                let density = min(1, speechTime / max(1, end - start))
                let complete = boundaries.contains { abs($0 - end) < 0.2 } ? 1.0 : 0.0
                score = 17 + hook * 18 + pace * 13 + variety * 10 + density * 12 + complete * 10 + relativeEnergy * 10 + variation * 5
                if hook > 0 { reasons.append("Strong opening language") }
                if pace > 0.65 { reasons.append("Clear speaking pace") }
                if complete > 0 { reasons.append("Ends at a speech boundary") }
                if density > 0.65 { reasons.append("Little dead air") }
            } else {
                score = 20 + relativeEnergy * 28 + active * 22 + variation * 12
                if relativeEnergy > 0.65 { reasons.append("Above-average audio energy") }
                if active > 0.7 { reasons.append("Consistent audio activity") }
                if variation > 0.45 { reasons.append("Dynamic audio") }
            }
            if peak < 0.0001 && tokens.isEmpty { score = 10; reasons = ["No usable speech or audio signal"] }
            if reasons.isEmpty { reasons = [tokens.isEmpty ? "Audio activity match" : "Speech content match"] }
            let title = text.split(whereSeparator: \.isWhitespace).prefix(10).joined(separator: " ")
            candidates.append(RankedMoment(start: start, end: end, score: max(1, min(99, Int(score.rounded()))),
                                           title: title.isEmpty ? "Highlight at \(ClipLogic.timestamp(start))" : title,
                                           reasons: reasons, usesSpeech: !tokens.isEmpty))
        }
        candidates.sort { $0.score == $1.score ? $0.start < $1.start : $0.score > $1.score }
        var picked: [RankedMoment] = []
        for candidate in candidates {
            let overlaps = picked.contains {
                let overlap = max(0, min($0.end, candidate.end) - max($0.start, candidate.start))
                return overlap > min($0.end - $0.start, candidate.end - candidate.start) * 0.15
            }
            if !overlaps { picked.append(candidate) }
            if picked.count >= count { break }
        }
        return picked
    }

    static func relativeCaptions(_ captions: [Caption], start: Double, end: Double) -> [Caption] {
        captions.compactMap { cue in
            let lower = max(start, cue.start), upper = min(end, cue.start + cue.duration)
            guard upper > lower else { return nil }
            return Caption(start: lower - start, duration: upper - lower, text: cue.text)
        }
    }
}
