import AVFoundation
import UIKit

struct TextOverlay {
    let image: CGImage
    let frame: CGRect
    let start: Double
    let end: Double
}

final class ClipInstruction: NSObject, AVVideoCompositionInstructionProtocol {
    let timeRange: CMTimeRange
    let enablePostProcessing = false
    let containsTweening = false
    let requiredSourceTrackIDs: [NSValue]?
    let passthroughTrackID = kCMPersistentTrackID_Invalid
    let trackID: CMPersistentTrackID
    let transform: CGAffineTransform
    let size: CGSize
    let overlays: [TextOverlay]

    init(trackID: CMPersistentTrackID, duration: CMTime, transform: CGAffineTransform,
         sourceSize: CGSize, size: CGSize, captions: [Caption], headline: String?, style: CaptionStyle) {
        self.trackID = trackID
        self.timeRange = CMTimeRange(start: .zero, duration: duration)
        self.requiredSourceTrackIDs = [NSNumber(value: trackID)]
        self.size = size
        // AVFoundation transforms use top-left coordinates; Core Image uses bottom-left.
        let sourceFlip = CGAffineTransform(a: 1, b: 0, c: 0, d: -1, tx: 0, ty: sourceSize.height)
        let outputFlip = CGAffineTransform(a: 1, b: 0, c: 0, d: -1, tx: 0, ty: size.height)
        self.transform = sourceFlip.concatenating(transform).concatenating(outputFlip)
        var layers: [TextOverlay] = []
        if let headline, !headline.isEmpty,
           let image = Self.text(headline.uppercased(), size: CGSize(width: size.width * 0.84, height: size.height * 0.15),
                font: size.width * 0.037, color: .black, background: UIColor.white.withAlphaComponent(0.92), outlined: false) {
            layers.append(TextOverlay(image: image, frame: CGRect(x: size.width * 0.08,
                y: size.height * 0.75, width: size.width * 0.84, height: size.height * 0.15), start: 0, end: duration.seconds))
        }
        let fontSize = size.width * (style == .clean ? 0.046 : 0.057)
        let color = style == .mint ? UIColor(red: 0.65, green: 1, blue: 0.58, alpha: 1) : UIColor.white
        for caption in captions where caption.duration > 0 && !caption.text.isEmpty {
            if let image = Self.text(style == .clean ? caption.text : caption.text.uppercased(),
                size: CGSize(width: size.width * 0.86, height: fontSize * 4.8), font: fontSize,
                color: color, background: UIColor.black.withAlphaComponent(style == .clean ? 0.7 : 0.18), outlined: true) {
                layers.append(TextOverlay(image: image, frame: CGRect(x: size.width * 0.07,
                    y: size.height * 0.12, width: size.width * 0.86, height: fontSize * 4.8),
                    start: max(0, caption.start), end: min(duration.seconds, caption.start + caption.duration)))
            }
        }
        self.overlays = layers
        super.init()
    }

    private static func text(_ text: String, size: CGSize, font: CGFloat, color: UIColor,
                             background: UIColor, outlined: Bool) -> CGImage? {
        let format = UIGraphicsImageRendererFormat()
        format.scale = 1; format.opaque = false
        let image = UIGraphicsImageRenderer(size: size, format: format).image { context in
            let paragraph = NSMutableParagraphStyle()
            paragraph.alignment = .center; paragraph.lineBreakMode = .byWordWrapping
            var attributes: [NSAttributedString.Key: Any] = [.font: UIFont.boldSystemFont(ofSize: font),
                .foregroundColor: color, .paragraphStyle: paragraph]
            let available = CGSize(width: size.width - 24, height: size.height - 24)
            var fitted = font
            while fitted > 12 {
                attributes[.font] = UIFont.boldSystemFont(ofSize: fitted)
                let measured = (text as NSString).boundingRect(with: CGSize(width: available.width, height: .greatestFiniteMagnitude),
                    options: [.usesLineFragmentOrigin, .usesFontLeading], attributes: attributes, context: nil)
                if measured.height <= available.height && measured.width <= available.width { break }
                fitted -= 1
            }
            let measured = (text as NSString).boundingRect(with: CGSize(width: available.width, height: .greatestFiniteMagnitude),
                options: [.usesLineFragmentOrigin, .usesFontLeading], attributes: attributes, context: nil)
            guard measured.height <= available.height && measured.width <= available.width else { return }
            background.setFill()
            UIBezierPath(roundedRect: CGRect(origin: .zero, size: size), cornerRadius: 10).fill()
            if outlined { attributes[.strokeColor] = UIColor.black; attributes[.strokeWidth] = -3 }
            (text as NSString).draw(in: CGRect(x: 12, y: (size.height - min(available.height, measured.height)) / 2,
                                             width: available.width, height: available.height),
                                    withAttributes: attributes)
            _ = context
        }
        return image.cgImage
    }
}

/// Draw cached text directly into CPU-accessible frames, with no offscreen GPU renderer.
final class CaptionCompositor: NSObject, AVVideoCompositing {
    var sourcePixelBufferAttributes: [String: Any]? {
        [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA]
    }
    var requiredPixelBufferAttributesForRenderContext: [String: Any] {
        [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA]
    }
    private let queue = DispatchQueue(label: "loik.video.render")
    private let lock = NSLock()
    private var generation = 0
    private let colorSpace = CGColorSpaceCreateDeviceRGB()

    func renderContextChanged(_ newRenderContext: AVVideoCompositionRenderContext) {}

    func startRequest(_ request: AVAsynchronousVideoCompositionRequest) {
        lock.lock(); let token = generation; lock.unlock()
        queue.async { [self] in
            autoreleasepool {
                lock.lock(); let cancelled = token != generation; lock.unlock()
                if cancelled { request.finishCancelledRequest(); return }
                guard let instruction = request.videoCompositionInstruction as? ClipInstruction,
                      let source = request.sourceFrame(byTrackID: instruction.trackID),
                      let destination = request.renderContext.newPixelBuffer() else {
                    request.finish(with: LoikError.message("The video frame could not be rendered.")); return
                }
                CVPixelBufferLockBaseAddress(source, .readOnly)
                CVPixelBufferLockBaseAddress(destination, [])
                defer {
                    CVPixelBufferUnlockBaseAddress(destination, [])
                    CVPixelBufferUnlockBaseAddress(source, .readOnly)
                }
                let bitmap = CGBitmapInfo.byteOrder32Little.rawValue | CGImageAlphaInfo.premultipliedFirst.rawValue
                guard let input = CGContext(data: CVPixelBufferGetBaseAddress(source),
                    width: CVPixelBufferGetWidth(source), height: CVPixelBufferGetHeight(source),
                    bitsPerComponent: 8, bytesPerRow: CVPixelBufferGetBytesPerRow(source), space: colorSpace,
                    bitmapInfo: bitmap), let image = input.makeImage(),
                    let canvas = CGContext(data: CVPixelBufferGetBaseAddress(destination),
                    width: CVPixelBufferGetWidth(destination), height: CVPixelBufferGetHeight(destination),
                    bitsPerComponent: 8, bytesPerRow: CVPixelBufferGetBytesPerRow(destination), space: colorSpace,
                    bitmapInfo: bitmap) else {
                    request.finish(with: LoikError.message("Could not access the video frame pixels.")); return
                }
                canvas.setFillColor(UIColor.black.cgColor)
                canvas.fill(CGRect(origin: .zero, size: instruction.size))
                if let backdrop = CGContext(data: nil, width: 16, height: 16, bitsPerComponent: 8,
                    bytesPerRow: 64, space: colorSpace, bitmapInfo: bitmap) {
                    backdrop.interpolationQuality = .high
                    backdrop.draw(image, in: CGRect(x: 0, y: 0, width: 16, height: 16))
                    if let softened = backdrop.makeImage() {
                        canvas.interpolationQuality = .high
                        canvas.draw(softened, in: CGRect(origin: .zero, size: instruction.size))
                        canvas.setFillColor(UIColor.black.withAlphaComponent(0.35).cgColor)
                        canvas.fill(CGRect(origin: .zero, size: instruction.size))
                    }
                }
                canvas.saveGState()
                canvas.concatenate(instruction.transform)
                canvas.draw(image, in: CGRect(x: 0, y: 0, width: image.width, height: image.height))
                canvas.restoreGState()
                let time = request.compositionTime.seconds
                for overlay in instruction.overlays where time >= overlay.start && time < overlay.end {
                    canvas.draw(overlay.image, in: overlay.frame)
                }
                lock.lock(); let stopped = token != generation; lock.unlock()
                if stopped { request.finishCancelledRequest() }
                else { request.finish(withComposedVideoFrame: destination) }
            }
        }
    }

    func cancelAllPendingVideoCompositionRequests() {
        lock.lock(); generation += 1; lock.unlock()
    }
}
